﻿Imports Microsoft.VisualBasic
Imports System.Runtime.Serialization
Imports System.Runtime.Serialization.Json
Imports System.IO
Imports System.IO.Compression
Imports System.Text
Imports System.Web
Imports System.Web.Script.Serialization

Partial Class lib_Default
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load

        Dim BodyJson As IO.Stream
        Dim BodyEncode As Text.Encoding
        Dim BodyRead As IO.StreamReader
        Dim BodyJsonEnd As String = ""
        Dim Serializer As New DataContractJsonSerializer(GetType(Definitions.ClientJson))
        Dim StreamJson As New MemoryStream
        Dim RootObject As New Definitions.ClientJson
        Dim JsSerie As New JavaScriptSerializer
        Dim ReturnString As String = ""
        Dim WorkData As New Functions

        Try

            If Request.QueryString.AllKeys.Contains("requiredjs") = False Then

                BodyJson = Request.InputStream
                BodyEncode = Request.ContentEncoding
                BodyRead = New IO.StreamReader(BodyJson, BodyEncode)
                BodyJsonEnd = BodyRead.ReadToEnd

                WorkData.MyRequest = Request
                If Request.Files.Count = 0 Then
                    StreamJson = New MemoryStream(Encoding.UTF8.GetBytes(BodyJsonEnd))
                    RootObject = DirectCast(Serializer.ReadObject(StreamJson), Definitions.ClientJson)
                    StreamJson.Close()
                Else
                    RootObject = WorkData.UploadFileServer(Request.Files, Request.Cookies)
                End If

                RootObject.Encoding = BodyEncode.HeaderName
                RootObject = WorkData.WorkJson(RootObject)
                JsSerie.MaxJsonLength = Int32.MaxValue
                ReturnString = JsSerie.Serialize(RootObject)

                Response.ContentType = "application/json"

            Else

                Response.ContentType = "application/javascript"
                ReturnString &= "AddRemoteJsCssFile(" & JsSerie.Serialize(WorkData.PagerLoader(Nothing, "Plugin")) & ");"
                ReturnString &= "AddRemoteJsCssFile(" & JsSerie.Serialize(WorkData.PagerLoader(Nothing, "Theme")) & ");"

            End If

        Catch ex As Exception
            ReturnString = ex.Message
        End Try

        Response.ContentEncoding = Encoding.UTF8
        Response.AppendHeader("Access-Control-Allow-Origin", "*")
        Response.Clear()
        Response.Write(ReturnString)
        Response.End()

    End Sub
End Class
