//Standar Params
$.local_data = {};
$.prev_data = {};
$.load_app = false;
$.title_app = '';
$.hash = [];
$.config = {
    default_title_app: '',
    before_load_app: '',
    after_load_app: '',
    before_load_page: '',
    after_load_page: '',
    after_load_menu: '',
    time_form: 1000,
    service_paths: 'http://localhost:55041/',
    service_url: 'http://localhost:55041/lib/',
    user_language: navigator.userLanguage || navigator.language,
    default_menu_app: '',
    messages: {
        es: {
            load_app: '<i class="fa fa-cog fa-spin"></i> Cargando sitio web ....',
            wait_button: '<i class="fa fa-refresh fa-spin"></i> Trabajando ...',
            modal_step: '<i class="fa fa-refresh fa-spin"></i> Trabajando tan rapido como podemos, espere unos segundos ...',
            load_table: '<i class="fa fa-refresh fa-spin"></i> Cargando tabla ....',
            load_ws: '<i class="fa fa-refresh fa-spin"></i> Cargando elemento solicitado ....',
            wellcome_user: '<strong>Hola</strong> ',
            login_button: '<i class="fa fa-refresh fa-spin"></i> Validando ...',
            delete_box: {
                title: '<i class="fa fa-question-circle" aria-hidden="true"></i> Eliminando registro',
                message: '¿Esta seguro de eliminar el registro seleccionado?',
                button: '<i class="fa fa-trash" aria-hidden="true"></i> Si, eliminar!',
                title_wait: 'Eliminacion en proceso',
                message_wait: '<i class="fa fa-spinner fa-spin"></i> Se esta eliminando el registro',
                title_verify: '<i class="fa fa-info-circle" aria-hidden="true"></i> Verificando registros',
                message_verify: '<i class="fa fa-spinner fa-spin"></i> Estamos verificando su registros antes de procederlo a eliminar',
                title_locked: '<i class="fa fa-exclamation-circle" aria-hidden="true"></i> Imposible eliminar',
                message_locked: '<i class="fa fa-hand-paper-o" aria-hidden="true"></i> No podemos eliminar este registro, el motivo puede estar asociado a que el registro esta siendo usado en otro proceso.'
            }
        }
    },
    locations: {
        user_full_name: { name: '.user-full-name' },
        body_page_content: { name: '.body-content' },
        body_page_title: { name: '.body-page-title' },
        body_page_descrip: { name: '.body-page-descrip' }
    },
    options : {},
    initial: function () {
        $.local_data = {};
        $.prev_data = {};
        $.load_app = false;
        $.title_app = '';
        $.config.options = {}
    },
    params: {
        path_theme:'inc/media',
        media_home: 'inc/media/',
        media_theme: 'inc/media/'
    },
    table: {
        rowCount: [50, 100, 150, 200, 250, 300, -1],
        onSuccess: function (objectTable) {
            objectTable.removeClass('bootgrid-table');
        }
    },
    login: [
        {
            code: 7, //Pending
            action: function (MyForm, MyData, MyAlert) {
                var alertBox = MyAlert || '#login-alert';
                $(alertBox).DisplayAlert({
                    Prev: '<i class="fa fa-exclamation-circle"></i> Hola ' + MyData.SESSIONNAME,
                    Html: 'tu cuenta esta esta pendiente de verificaci&oacute;n.',
                    Class: 'warning'
                });
            }
        },
        {
            code: 8, //Active
            action: function (MyForm, MyData, MyAlert) {
                var alertBox = MyAlert || '#login-alert';
                $(alertBox).html('');
                for (var item in MyData) {
                    localStorage.setItem(item, MyData[item]);
                };
                document.location = '#?start=true';
            }
        },
        {
            code: 9, //Suspending
            action: function (MyForm, MyData, MyAlert) {
                var alertBox = MyAlert || '#login-alert';
                $(alertBox).DisplayAlert({
                    Prev: '<i class="fa fa-exclamation-circle"></i> Hola ' + MyData.SESSIONNAME,
                    Html: 'tu cuenta esta esta suspendida no puedes ingresar al sistema.',
                    Class: 'warning'
                });
            }
        }
    ],
    hash: {
        'start': function () {
            $.config.initial();
            $.StartApp();
        },
        'close': function () {
            $.CleanCookie();
            session_id = localStorage.getItem('SESSIONID') || -1;
            $.config.initial();
            $.StartApp();
        },
        'set_app': function (value) {
            localStorage.setItem('SESSIONAPP', value);
            if ($.load_app == false) {
                $.StartApp();
            } else {
                $.LoadApp();
                $.CreateMenu();
            };
        },
        'set_theme': function (value) {
            localStorage.setItem('SESSIONAPP', value);
            $.config.initial();
            $.StartApp();
        }

    }
};
