﻿$.fn.extend({
    OnlyDecimal: function (decimals) {
        var mydecimals = decimals || 2;
        return this.each(function () {
            $(this).bind('keydown', function (event) {
                if ((event.keyCode == 8 || event.keyCode == 46 || event.keyCode == 9 || event.keyCode == 37 || event.keyCode == 39 || event.keyCode == 110 || event.keyCode == 190)) {
                } else {
                    if (!((event.keyCode >= 48 && event.keyCode <= 57) || (event.keyCode >= 96 && event.keyCode <= 105))) {
                        event.preventDefault();
                    };
                };
            });
            $(this).bind('change', function (event) {
                if ($(this).val() != '') {
                    var decNumber = parseFloat($(this).val());
                    $(this).val(decNumber.toFixed(mydecimals));
                };
            });
        });
    },
    OnlyNumeric: function () {
        return this.each(function () {
            $(this).bind('keydown', function (event) {
                if (event.keyCode == 8 || event.keyCode == 46 || event.keyCode == 9 || event.keyCode == 37 || event.keyCode == 39) {
                } else {
                    if (!((event.keyCode >= 48 && event.keyCode <= 57) || (event.keyCode >= 96 && event.keyCode <= 105))) {
                        event.preventDefault();
                    };
                };
            });
        });
    },
    OnlyText: function () {
        return this.each(function () {
            $(this).bind('keydown', function (event) {
                if (event.keyCode == 8 || event.keyCode == 46 || event.keyCode == 9 || event.keyCode == 37 || event.keyCode == 39) {
                } else {
                    if (((event.keyCode >= 48 && event.keyCode <= 57) || (event.keyCode >= 96 && event.keyCode <= 105))) {
                        event.preventDefault();
                    };
                };
            });
        });
    },
    LimitChar: function (NumLimit, Action, Negative) {
        if (typeof Action == 'undefined') {
            Action = function (control, value) { };
        };
        if (typeof Negative == 'undefined') {
            Negative = function (control, value) { };
        };
        return this.each(function () {
            var total_call = 0;
            $(this).unbind('keyup');
            $(this).bind('keyup', function (event) {
                var total_char = $(this).val().length;
                if (total_char == NumLimit) {
                    total_call++;
                    if (total_call == 1) {
                        Action($(this), $(this).val(), event);
                    };
                } else {
                    if (total_call > 0) {
                        total_call = 0;
                    };
                    Negative($(this), $(this).val());
                };
            });
        });
    }
});