﻿$(document).ready(function () {
    //No conflit jquery
    jQuery.noConflict;
    //Start WOW Animation Class
    wow = new WOW({
        animateClass: 'animated',
        offset: 50
    });
    wow.init();
    //Hash Events
    $(window).hashchange(function () {
        var params_hash = $.GetURLToArray('<<ARRAY>>');
        var params_found = false;
        for (var item in params_hash) {
            if (typeof $.config.hash[item] !== 'undefined' && typeof $.config.hash[item]=='function') {
                params_found = true;
                $.config.hash[item](params_hash[item]);
            };
        };
        if (params_found == false) {
            $.GetPage();
        };
    });
    $(window).trigger('hashchange');
});