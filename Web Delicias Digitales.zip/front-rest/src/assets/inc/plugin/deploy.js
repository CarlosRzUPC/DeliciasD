//Plugin Framework
$.extend({
    GetData: function (options) {

        $.browser.Url = location.hash;

        var onData = options.onData || {};
        var onBefore = options.onBefore;
        var onSuccess = options.onSuccess;
        var service_data = '';
        var onSession = {};
        var onBrowser = $.ConvertJsonAlexa($.browser);
        var onOperacion = options.onOperacion || 'Transaccion';
        var onContentType = 'text/plain';
		    var onSessionTemp = {};

        if (localStorage.length !== 0) {
            for (var i = 0; i<localStorage.length; i++) {
                onSessionTemp[localStorage.key(i)]=localStorage.getItem(localStorage.key(i));
            }
            onSession = $.ConvertJsonAlexa(onSessionTemp);
        }
        if ((typeof onSuccess == "undefined") || (typeof onSuccess != 'function')) {
            onSuccess = function (Result) { };
        };
        if ((typeof onBefore == "undefined") || (typeof onBefore != 'function')) {
            onBefore = function () { };
        };

        onData.Operacion = onOperacion
        onData.Session = onSession;
        onData.Browser = onBrowser;

        service_data = JSON.stringify(onData);
        $.prev_data.Petition = [];

        if ($.browser.mobile) {
            onContentType = "application/json; charset=utf-8";
        };

        $.ajax({
            type: 'POST',
            url: $.config.service_url,
            data: service_data,
            dataType: 'json',
            contentType: onContentType,
            processData: true,
            global: true,
            async: true,
            cache: false,
            beforeSend: onBefore,
            error: function (jqXHR, textStatus, errorThrown) {
                //Crear un Log Virtual
            },
            success: function (Result) {
                onSuccess($.SaveData(Result));
            },
            xhrFields: {
                withCredentials: false
            },
            crossDomain: true
        });
    },
    AddData: function (options) {
        var ConvertData = options.ConvertData || false;
        var URLdata = $.ConvertJsonAlexa($.GetURLToArray('<<ARRAY>>'));
        var addSaveData;
        if ((typeof $.prev_data.Petition == "undefined")) $.prev_data.Petition = [];
        if ((typeof options.Data == "undefined")) options.Data = [];
        if ((typeof options.Name == "undefined")) options.Name = $.CreateEncode();
        if (ConvertData == true) options.Data = $.ConvertJsonAlexa(options.Data);
        options.Data = options.Data.concat(URLdata);
        addSaveData = $.ConvertJsonAlexa($.prev_data.SaveParams);
        options.Data = options.Data.concat(addSaveData);
        $.prev_data.Petition.push(options);
        return options.Name;
    },
    SendData: function (options) {
        var SendingData = {};
        var TempData = {};
        var onBefore = options.onBefore;
        var onSuccess = options.onSuccess;
        var onOperacion = options.onOperacion || '';
        if ((typeof onBefore == "undefined") || (typeof onBefore != 'function')) {
            onBefore = function () { };
        };
        if ((typeof onSuccess == "undefined") || (typeof onSuccess != 'function')) {
            onSuccess = function (Result) { };
        };
        TempData.Petition = $.prev_data.Petition;
        SendingData = {
            onBefore: onBefore,
            onSuccess: onSuccess,
            onData: TempData,
            onOperacion: onOperacion
        };
        $.GetData(SendingData);
    },
    SaveData: function (Result) {
        var temp_result = Result;
        for (var item in temp_result.Petition) {
            var inRow = temp_result.Petition[item];
            var tmpResult = inRow.Result.Result;
            var tmpLog = inRow.Result.Log;
            var tmpNoSQL = {};
            if (typeof tmpResult.Cols != 'undefined') {
                for (var subItem in inRow.noSQL) {
                    if (typeof tmpResult.Cols[inRow.noSQL[subItem]] != 'undefined') {
                        for (var subrow in tmpResult.Data) {
                            var myRow = tmpResult.Data[subrow];
                            var inData = $.parseJSON(myRow[inRow.noSQL[subItem]]);
                            for (var addCol in inData) {
                                myRow[addCol] = inData[addCol];
                            };
                        };
                    };
                };
            };
            $.local_data[inRow.Name] = {
                Query: inRow.Query,
                Log: tmpLog,
                Result: tmpResult
            };
        };
        return $.local_data;
    },
    GetPage: function (myoptions) {

        var options = myoptions || {};
        var onBefore = options.onBefore || $.config.before_load_page;
        var onWorking = '';
        var onSuccess = options.onSuccess || $.config.after_load_page;
        var onName = $.CreateEncode();
        var onAction = 'GetPage';
        var onLocation = 'body_page_content';

        if ($.GetURLToArray('location') !== '') { onLocation = $.GetURLToArray('location'); };
        if ($.GetURLToArray('action') !== '') { onAction = $.GetURLToArray('action'); };
        if (onAction == 'GetTheme') { onLocation = 'body' };

        if ((typeof onBefore == "undefined") || (typeof onBefore != 'function')) {
            onBefore = function () { };
        };
        if ((typeof onWorking == "undefined") || (typeof onWorking != 'function')) {
            onWorking = function (Result) {
                var onObject = $.GetLocation(onLocation);
                $.SetPage({ onName: onName, onObject: onObject });
                onSuccess(onObject);
            };
        };
        if ((typeof onSuccess == "undefined") || (typeof onSuccess != 'function')) {
            onSuccess = function () { };
        };

        if ($.load_app == false) {
            $.StartApp({
                onSuccess: function () {
                    $.AddData({ Name: onName, Exec: onAction });
                    $.SendData({ onBefore: onBefore, onSuccess: onWorking });
                }
            });
        } else {
            $.AddData({ Name: onName, Exec: onAction });
            $.SendData({ onBefore: onBefore, onSuccess: onWorking });
        };

    },
    SetTitle: function (title_update) {
        if ($.title_app == '') {
            $.title_app = $.config.default_title_app;
        };
        document.title = $.title_app + ' :: ' + title_update;
        $.GetLocation('body_page_title').run(title_update);
        //$.GetLocation('header_app_title').run($.title_app);
        $.GetLocation('user_full_name').run($.GetMessage('wellcome_user') + localStorage.getItem('SESSIONNAME')); ///separar
    },
    SetPage: function (options) {
        var onName = options.onName;
        var onSuccess = options.onSuccess;
        var onObject = options.onObject || $.GetLocation('body');
        var onData = $.local_data[onName];
        if ((typeof onSuccess == "undefined") || (typeof onSuccess != 'function')) {
            onSuccess = function () {};
        };
        if ((!(typeof onObject == "undefined") && !(typeof onData == "undefined"))) {
            var onResult = onData.Result;
            for (var param in $.config.params) {
                onResult.HTML = onResult.HTML.replace('{{' + param + '}}', $.config.params[param]);
            };
            if (onResult.Mode == 'html') {
                onObject.run(onResult.HTML);
                $.SetTitle(onResult.Title);
            };
            onSuccess();
        };
    },
    ShowModal: function (options) {
        $('body').append('<div id="modal-show-step" class="modal" role="dialog">' + $.GetMessage('modal_step') + '</div>');
        $('#modal-show-step').modal({
            show: 'toggle',
            keyboard: false
        });
    },
    CloseModal: function () {
        $('#modal-show-step').modal('toggle');
        $('#modal-show-step').remove();
    },
    GetURLToArray: function (param) {
        var url = location.hash;
        var request = {};
        var param_find = param || 0;
        var return_value;
        var pairs = url.substring(url.indexOf('?') + 1).split('&');
        var total_param = 0;
        for (var i = 0; i < pairs.length; i++) {
            var pair = pairs[i].split('=');
            if (pair[0].length > 0) {
                request[decodeURIComponent(pair[0])] = decodeURIComponent(pair[1]);
                total_param++;
            };
        };
        if (param_find != '<<ARRAY>>') {
            if (param_find != 0) {
                if ((typeof request[param] == "undefined")) {
                    return_value = '';
                } else {
                    return_value = request[param];
                };
            } else {
                return_value = total_param;
            };
        } else {
            return_value = request;
        };
        return return_value;
    },
    CleanCookie: function () {
        var nowCookie = localStorage;
        for (var item in nowCookie) {
            localStorage.removeItem(item);
        };
    },
    StartApp: function (myoptions) {
        var options = myoptions || {};
        var session_id = localStorage.getItem('SESSIONID') || -1;
        var onBefore = function () {
            if (typeof $.config.before_load_app === 'function') $.config.before_load_app();
            onWorking();
        };
        var onSuccess = function () {
            if (typeof $.config.after_load_app === 'function') $.config.after_load_app();
            if (typeof options.onSuccess != 'undefined' && typeof options.onSuccess == 'function') options.onSuccess();
        };
        var onWorking = function () {
            if (session_id !== -1) { $.LoadApp(); }
            $.SetPage({ onName: $.config.keys.theme });
            $.CreateMenu();
            onSuccess();
            $.load_app = true;
        };
        var onBeforeConection = function () {
            $('body').html($.GetMessage('load_app'));
        };
        var onSuccessConection = function () {
            onBefore();
        };
        if (typeof $.config.keys == 'undefined') $.config.keys = {};
        $.config.keys.theme = $.AddData({ Exec: 'GetTheme' });
        if (session_id !== -1) {
            $.config.keys.application = $.AddData({ Exec: 'getQuery', Data: [{ name: 'codeQuery', value: "T_AppActive" }] });
            $.config.keys.options = $.AddData({ Exec: 'getQuery', Data: [{ name: 'codeQuery', value: "T_MenuUser" }] });
        };
        moment.locale($.config.user_language);
        $.SendData({ onBefore: onBeforeConection, onSuccess: onSuccessConection });
    },
    LoadApp: function (myoptions) {

        var app_active = localStorage.getItem('SESSIONAPP') || 0;
        var app_user = $.local_data[$.config.keys.application].Result;
        var app_data = {};
        var menu_user = $.local_data[$.config.keys.options].Result;
        var menu_data = {};

        for (var item in $.config.locations) {
            var inRow = $.config.locations[item];
            if (typeof inRow.ready != 'undefined') inRow.ready = false;
        };
        $.config.options = {}
        if (app_user.Rows == 0) {
            //No tiene permiso a ninguna app, error call app
        } else {

            if (app_active == 0) {
                app_data = app_user.Data[0];
            } else {
                for (var item in app_user.Data) {
                    var inRow = app_user.Data[item];
                    if (inRow.SESSIONAPP == app_active) {
                        app_data = inRow;
                        break;
                    };
                };
            };
            $.title_app = app_data.SESSIONAPPTITLE;
            for (var item in app_data) {
                localStorage.setItem(item, app_data[item]);
            };

            $.config.options['MENU_0'] = {
                id: app_data.SESSIONAPP,
                location: $.config.default_menu_app,
                name: $.title_app,
                order: 0,
                align: '',
                options: {
                    'APP_0': {
                        action: '#',
                        title: app_data.SESSIONAPPTITLESHORT,
                        icon: '',
                        level: 1,
                        app: app_data.SESSIONAPP,
                        options: {}
                    }
                }
            };
            for (var item in app_user.Data) {
                var inRow = app_user.Data[item];
                if (inRow.SESSIONAPP !== app_data.SESSIONAPP) {
                    $.config.options['MENU_0'].options['APP_0'].options['APP_' + inRow.SESSIONAPP] = {
                        action: '#?set_theme=' + inRow.SESSIONAPP + '&path=' + inRow.SESSIONAPPTHEME,
                        title: inRow.SESSIONAPPTITLE,
                        icon: '',
                        app: app_data.SESSIONAPP,
                        level: 2
                    };
                };
            };

            if (menu_user.Rows != 0) {
                for (var item in menu_user.Data) {
                    var inRow = menu_user.Data[item];
                    if (typeof $.config.options[inRow.Menu] === 'undefined') {
                        $.config.options[inRow.Menu] = {
                            id: inRow.Menu,
                            location: inRow.Ubicacion,
                            name: inRow.Nombre,
                            order: inRow.OrdenMenu,
                            align: inRow.Alinear,
                            options: {}
                        };
                    };
                    $.AddMenu(inRow, $.config.options[inRow.Menu]);
                };
            };
            
        };

    },
    AddMenu: function (item, menu, level) {
        var i_level = level || 1;
        var t_object = {};
        var s_object = {
            title: item.Etiqueta,
            action: item.Action,
            icon: item.Icono,
            level: i_level,
            app: item.SESSIONAPP
        };
        if (item.Parent == '') {
            menu.options[item.Item] = s_object;
        } else {
            t_object = $.FindMenu(item.Parent, menu.options);
            if (typeof t_object != "undefined") {
                if (typeof t_object.options == "undefined") {
                    t_object.options = {};
                };
                s_object.level = t_object.level + 1;
                if (s_object.icon == '') s_object.icon = '<i class="fa fa-angle-double-right"></i>';
                t_object.options[item.Item] = s_object;
            };
        };
        return menu;
    },
    FindMenu: function (name, options) {
        var r_object;
        for (var item in options) {
            var inRow = options[item];
            if (item == name) {
                r_object = inRow;
                break;
            } else {
                if (typeof inRow.options != "undefined") {
                    r_object = $.FindMenu(name, inRow.options);
                    if (typeof r_object != 'undefined') {
                        break;
                    };
                };
            };
        };
        return r_object;
    },
    CreateMenu: function () {

        for (var item in $.config.options) {
            var menu = $.config.options[item];
            var menu_object = $.GetLocation(menu.location);
            if (typeof menu.token === 'undefined') menu.token = $.CreateEncode();
            if (menu_object.object.length) {
                if (!$(menu_object.object).find('.navbar-collapse').length) {
                    menu_object.object.html('<div class="navbar navbar-default" role="navigation"><div class="navbar-header"></div><div class="navbar-collapse collapse"></div></div>');
                    if (menu.location === $.config.default_menu_app) {
                        menu_object.object.find('.navbar-header').append('<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target=".navbar-collapse" aria-expanded="false"></button>');
                        menu_object.object.find('.navbar-header').find('button').append('<span class="sr-only">Toggle navigation</span>');
                        menu_object.object.find('.navbar-header').find('button').append('<span class="icon-bar"></span>');
                        menu_object.object.find('.navbar-header').find('button').append('<span class="icon-bar"></span>');
                        menu_object.object.find('.navbar-header').find('button').append('<span class="icon-bar"></span>');
                        //menu_object.object.find('.navbar-header').append('<a class="navbar-brand" href="#"><img src="' + $.config.params.media_theme + 'alexacms_logo_white.png" class="img-responsive" /></a>');
                    };
                };
                $(menu_object.object).find('ul.' + item).remove();
                $(menu_object.object).find('.navbar-collapse').append('<ul id="' + menu.token + '" class="nav navbar-nav ' + item + '"></ul>');
                menu.object = $('ul#' + menu.token);
                if (menu.align == 'Derecha') menu.object.addClass('navbar-right');
                if (menu.align == 'Izquierda') menu.object.addClass('navbar-left');
                $.CreateMenuItem(menu_object.object.find('ul').last(), menu.options);
                if (typeof $.config.after_load_menu === 'function') {
                    $.config.after_load_menu(menu);
                };
            };
            menu_object.run();
        };

    },
    CreateMenuItem: function (object, options) {
        var object_item;
        var token_item;
        for (var item in options) {
            var inRow = options[item];
            if (inRow.app === localStorage.getItem('SESSIONAPP')) {
                token_item = $.CreateEncode();
                object.append('<li class="' + item + '"><a></a></li>');
                object_item = object.find('li').last();
                object_item.find('a').append('<span class="title" id="' + token_item + '"></span>');
                object_item.find('a').attr('href', inRow.action);
                if (typeof inRow.level == "undefined") inRow.level = 0;
                if (typeof inRow.class == "undefined") inRow.class = '';
                if (inRow.icon != '') object_item.find('a').prepend(inRow.icon + ' ');
                if (typeof inRow.options != "undefined") {
                    if (inRow.level > 1) {
                        object_item.addClass('dropdown-submenu');
                    } else {
                        object_item.addClass('dropdown');
                        object_item.find('a').append('<span class="caret"></span>');
                    };
                    object_item.find('a').attr('href', '#').addClass('dropdown-toggle').attr('data-toggle', 'dropdown');
                    object_item.append('<ul class="dropdown-menu" role="menu"></ul>');
                    $.CreateMenuItem(object_item.find('ul'), inRow.options);
                } else {
                    object_item.find('a').attr('data-toggle', 'collapse');
                    object_item.find('a').attr('data-target', '.navbar-collapse.in');
                };
                object_item.find('a').find('#' + token_item).html(inRow.title).addClass(inRow.class);
                inRow.object = object_item;
            };
        };
    },
    GetControl: function (form, control) {
        var find_control;
        for (var item in $.prev_data.Controls) {
            var inRow = $.prev_data.Controls[item];
            if (item == form) {
                for (var myitem in inRow) {
                    var subRow = inRow[myitem];
                    if (myitem == control) {
                        find_control = subRow.object;
                        break;
                    };
                }
            }
        };
        return $(find_control);
    },
    GetControlName: function (form, encode) {
        var find_name = encode;
        for (var item in $.prev_data.Controls) {
            var inRow = $.prev_data.Controls[item];
            if (item == form) {
                for (var myitem in inRow) {
                    var subRow = inRow[myitem];
                    if (subRow.encode == encode) {
                        find_name = myitem;
                        break;
                    };
                }
            }
        };
        return find_name;
    },
    CreateEncode: function (FormName, CtrlName) {
        var RFornName = FormName || Math.floor((Math.random() * 1000) + 1);
        var RCtrlName = CtrlName || Math.floor((Math.random() * 100) + 1);
        var EncodeText = md5(RFornName + '-' + RCtrlName);
        return EncodeText;
    },
    GetMessage: function (name) {
        var messages_cfg = $.config.messages[$.config.user_language];
        var messages_rtn = '';
        if (!(typeof messages_cfg[name] == "undefined")) {
            messages_rtn = messages_cfg[name];
        }
        return messages_rtn;
    },
    ConvertJsonAlexa: function (object) {
        var new_obecjt = [];
        for (var item in object) {
            var inrow = object[item];
            var inc_data = { name: item, value: '' };
            if (typeof (inrow) == 'object') {
                var sub_row = [];
                for (var subitem in inrow) {
                    sub_row.push({ name: subitem, value: inrow[subitem] });
                };
                inc_data.value = sub_row;
            } else {
                inc_data.value = inrow
            };
            new_obecjt.push(inc_data);
        };
        return new_obecjt;
    },
    UpdateHash: function (options) {
        var myOptions = options || { start: true };
        var myHask = '';
        var myUrl = $.GetURLToArray('<<ARRAY>>');
        bootbox.hideAll();
        for (var item in myOptions) {
            if (myHask.length != 0) myHask += '&';
            myHask += item + '=' + myOptions[item];
        };
        myHask = '#?' + myHask;
        window.location.hash = myHask;
        return '#?' + myHask;
    },
    GetLocation: function (nameLocation) {
        var location;
        var tokenLocation = $.CreateEncode();
        if (typeof $.config.locations[nameLocation] != 'undefined') {
            location = $.config.locations[nameLocation];
            if (typeof location.ready == 'undefined') {
                location.ready = false;
            };
            if ($(location.name).length) {
                if (typeof location.object == 'undefined') {
                    location.object = $(location.name);
                };
                location.parent = $(location.name);
                location.object = $(location.name);
                location.object.attr('id', tokenLocation);
            } else {
                $('body').append('<span id="' + tokenLocation + '"></span>');
                location.object = $('span#' + tokenLocation);
                location.object.css({ 'display': 'none' });
            };
            if (typeof location.success == 'undefined') {
                location.success = function (object, parent) {
                    //console.log('Run Location Token (**' + nameLocation + ') :: ' + $(object).attr('id'));
                };
            };
            if (typeof location.run == 'undefined') {
                location.run = function (html) {
                    var html_inner = html || '';
                    if (html_inner != '') location.object.html(html_inner);
                    location.success(location.object, location.parent);
                };
            };
            if (typeof location.html == 'undefined') {
                location.html = '';
            };
            if (location.html != '') {
                location.object.html(location.html);
                if (location.object.find('.content').length) {
                    location.object = location.object.find('.content');
                };
                location.ready = true;
            };
        } else {
            if ($(nameLocation).length) {
                $.config.locations[nameLocation] = { name: nameLocation };
                location = $.GetLocation(nameLocation);
            };
        };
        return location;
    },
    RemoveData: function (options) {
        var table = options.table || '';
        var condition = options.condition || '';
        var rows = options.rows || [];
        var verify = options.verify || [];
        var object = options.object;
        var message = options.message || $.GetMessage('delete_box');
        var actionCondition = function (isContidion) {
            var temp_condition = isContidion || condition;
            for (var item in rows) {
                temp_condition = temp_condition.replace('{{' + item + '}}', rows[item]);
            };
            return temp_condition;
        };
        var actionDelete = function () {
            var bootDelete = bootbox.dialog({
                message: message.message,
                title: message.title,
                buttons: {
                    success: {
                        label: message.button,
                        className: "btn-danger",
                        callback: function () {
                            var temp_condition = actionCondition();
                            var bootDeleteWait;
                            $.AddData({ Exec: 'SetData', Data: {}, ConvertData: true, Table: table, Type: 3, Condition: temp_condition });
                            $.SendData({
                                onBefore: function () {
                                    bootDeleteWait = bootbox.dialog({
                                        message: message.message_wait,
                                        title: message.title_wait,
                                        closeButton: false
                                    });
                                },
                                onSuccess: function () {
                                    setTimeout(function () {
                                        bootDelete.modal('hide');
                                        bootDeleteWait.modal('hide');
                                        $(object).bootgrid("reload");
                                    }, $.config.time_form);
                                }
                            });
                        }
                    },
                    cancel: {
                        label: '<i class="fa fa-times" aria-hidden="true"></i> Close',
                        className: "btn-primary"
                    }
                }
            });
        };
        var bootTemp;
        //Verificando Reglas
        if (verify.length != 0) {
            for (var item in verify) {
                var subRow = verify[item];
                if (typeof subRow.condition == 'undefined') {
                    subRow.condition = actionCondition();
                } else {
                    subRow.condition = actionCondition(subRow.condition);
                };
                subRow.token = $.AddData({
                    Exec: 'GetQuery',
                    Data: { table: subRow.table, codeQuery: 'BeforeDelete', 'Filter-Form': 'select count(1) as Total from({{Query}}) as A where ' + subRow.condition },
                    ConvertData: true
                });
            };
            $.SendData({
                onBefore: function () {
                    bootTemp = bootbox.dialog({
                        message: message.message_verify,
                        title: message.title_verify,
                        closeButton: false
                    });
                },
                onSuccess: function (Result) {
                    setTimeout(function () {
                        var total = 0;
                        bootTemp.modal('hide');
                        for (var item in verify) {
                            var subRow = verify[item];
                            var subData = Result[subRow.token];
                            total += parseInt(subData.Result.Data[0].Total);
                        };
                        if (total == 0) {
                            actionDelete();
                        } else {
                            bootbox.dialog({
                                message: message.message_locked,
                                title: message.title_locked,
                                closeButton: true
                            });
                        };
                    }, $.config.time_form);
                }
            });
        } else {
            actionDelete();
        };
        
    },
    QueryData: function (myname, mydata, myaction) {
        var name = myname || '';
        var data = mydata || {};
        var action = myaction || function () { };
        var token = '';

        if (name != '') {
            data.codeQuery = myname;
            token = $.AddData({ Exec: 'GetQuery', Data: data, ConvertData: true });
            $.SendData({
                onSuccess: function (result) {
                    var token_data = result[token].Result;
                    action(token_data);
                }
            });
        } else {
            //notificar
        };

        return token;
    }
});

//Extend Function to Objects
$.fn.extend({
    getJSON: function (mymode) {
        //vars Functions
        var mode = mymode || false;
        var tempSerialize = $(this).serializeArray();
        var form_name = $(this).attr('name');
        var ctrl_temp;
        var object_json = {};
        //Validation Previous Send to Service
        $.each(tempSerialize, function (i, field) {
            field.encripter = false;
            field.nosend = 0
            field.name = $.GetControlName(form_name, field.name);
            ctrl_temp = $.GetControl(form_name, field.name);
            if ($(ctrl_temp).is('[nosend]')) {
                field.nosend = 1
            };
            if ($(ctrl_temp).is('[encripter]')) {
                field.encripter = true;
            };
            object_json[field.name] = field.value;
        });
        //Return Array Correct
        if (mode == false) {
            return tempSerialize;
        } else {
            return object_json;
        };
    },
    setEncodeName: function () {
        var Ctrl = $(this);
        var Form = $(Ctrl).closest('form');
        var EncodeText = '';
        var FormName = '';
        var CtrlName = '';
        if (Form.length) {
            FormName = $(Form).attr('name');
        }
        CtrlName = $(Ctrl).attr('name');
        EncodeText = $.CreateEncode(FormName, CtrlName);
        return EncodeText;
    },
    isRequired: function () {
        return this.each(function () {
            var form = $(this).closest('form');
            var name = $(this).attr('name');
            var label = form.find('label[for=' + name + ']');
            if (label.length) {
                label.find('span').remove();
                label.removeClass('text-danger');
                if ($(this).is('[required]')) {
                    var text = label.text();
                    label.prepend('<span>*</span>');
                    label.addClass('text-danger');
                };
            };
        });
    },
    ValidForm: function (options) {
        return this.each(function () {
            //Vars of work Validation
            var form = $(this);
            var send = options.Send || false;
            var events = options.Events || {};
            var action = options.Action;
            var noSQL = options.noSQL || [];
            var rules = options.Rules;
            var exec = options.Exec || 'SetData';
            var button = $(this).find('button[type=submit]');
            var name = $(this).attr('name') || $.CreateEncode();
            var name_form_temp = name;
            var type = $(this).attr('type') || '0';
            var table = $(this).attr('table') || '';
            var condition = options.Condition || '';
            var button_text = options.ButtonText || $.GetMessage('wait_button');
            var ctrl_group;
            var codeQuery = options.codeQuery || '';
            var prev_button = $(button).html();
            var myToken = $.CreateEncode();
            var total_select = 0;
            var onSuccess = options.onSuccess;
            var prevAction = options.prevAction;
            var form_send = true;
            var onOperacion = options.onOperacion || 'Transaccion';

            if ($(button).is('[disabled]')) {
                form_send = false;
            };

            if ((typeof onSuccess == "undefined") || (typeof onSuccess != 'function')) {
                onSuccess = function (Result) { };
            };
            if ((typeof prevAction == "undefined") || (typeof prevAction != 'function')) {
                prevAction = function (Result) { };
            };

            $(this).removeAttr('type');
            $(this).removeAttr('table');

            if (typeof $.prev_data.TemParams == 'undefined') $.prev_data.TemParams = {};
            if ((typeof action == "undefined") || (typeof action != 'function')) {
                action = function (Result) {

                };
            };
            //Protect Controls on Form
            if ((typeof $.prev_data.Controls == "undefined")) {
                $.prev_data.Controls = {};
            };
            $.prev_data.Controls[name] = {}
            ctrl_group = $.prev_data.Controls[name];
            //Serialize Name Controls
            form.find('input,textarea,select,button').each(function (index, element) {
                var name_control = $(element).attr('name');
                var label = form.find('label[for=' + name_control + ']');
                var name_encode = $(element).setEncodeName();
                var ctrl_data = false;
                var ctrl_codeQuery = $(element).attr('codequery') || '';
                var ctrl_value = $(element).attr('data-value') || name_control;
                var ctrl_field = $(element).attr('data-field') || name_control;
                var ctrl_tabla = $(element).attr('tabla') || ''; //Para aplicacion pacifico
                var ctrl_type = $(element).prop('tagName');
                var ctrl_def = $(element).attr('default') || '';

                var ctrl_to = $(element).attr('data-to') || '';
                var ctrl_in = $(element).attr('data-in') || '';
                var load_def = false;

                //Values of default
                if (ctrl_def == '{{NOW}}') {
                    $(element).val(moment().format('YYYY/MM/DD HH:mm:ss'));
                    load_def = true
                };
                for (var item in $.prev_data.SaveParams) {
                    if (ctrl_def == '{{' + item + '}}') {
                        $(element).val($.prev_data.SaveParams[item]);
                        load_def = true;
                        break;
                    };
                };
                for (var item in localStorage) {
                    if (ctrl_def == '{{' + item + '}}') {
                        $(element).val(localStorage[item]);
                        load_def = true;
                        break;
                    };
                };
                if (load_def == false && ctrl_def != '') {
                    $(element).val(ctrl_def);
                };
                if (label.length) {
                    label.attr('for', name_encode);
                };

                $(element).removeAttr('codequery');
                $(element).removeAttr('data-value');
                $(element).removeAttr('data-field');
                $(element).removeAttr('data-to');
                $(element).removeAttr('data-in');

                //Default control params
                $(element).attr('autocomplete', 'off');
                if ($(element).is('[placeholder]')) {
                    //$(element).attr('data-toggle', 'tooltip');
                   // $(element).attr('data-placement', 'right');
                    $(element).attr('title', $(element).attr('placeholder'));
                    //$(element).tooltip();
                };

                if (ctrl_tabla != '') ctrl_codeQuery = 'T_GetTabla';
                if (ctrl_codeQuery != '') {
                    ctrl_data = true;
                    $.prev_data.TemParams['codeQuery'] = ctrl_codeQuery;
                    $.prev_data.TemParams['Tabla'] = ctrl_tabla; //Para Aplicacion pacifico
                    $.AddData({ Name: name_encode, Exec: 'getQuery', Data: $.prev_data.TemParams, ConvertData: true });
                    total_select++;
                };

                $(element).attr('name', name_encode);
                $(element).attr('id', name_encode);
                ctrl_group[name_control] = {
                    object: $(element),
                    type: ctrl_type,
                    encode: name_encode,
                    data: ctrl_data,
                    value: ctrl_value,
                    field: ctrl_field,
                    to: ctrl_to,
                    in: ctrl_in,
                    form: name
                };
                ctrl_group[name_encode] = {
                    object: $(element),
                    type: ctrl_type,
                    encode: name_encode,
                    data: false,
                    value: ctrl_value,
                    field: ctrl_field,
                    to: ctrl_to,
                    in: ctrl_in,
                    form: name
                };

                $(element).isRequired();

            });
            //Validate General Form Required
            form.validate({
                rules: rules,
                errorClass: 'label label-danger',
                validClass: 'success',
                highlight: function (element, errorClass, validClass) {
                    $(element).closest('.form-group').addClass('has-error').removeClass('has-success');
                },
                unhighlight: function (element, errorClass, validClass) {
                    $(element).closest('.form-group').removeClass('has-error').addClass('has-success');
                },
                submitHandler: function (hasform) {
                    var data;
                    var onBefore = function () {
                        $(hasform).find('input,textarea,select,button').each(function (index, element) {
                            $(element).attr('disabled', 'disabled');
                        });
                        $(button).html(button_text);
                        prevAction(name_form_temp, form);
                    };
                    var onSuccess = function (Result) {
                        setTimeout(function () {
                            $(hasform).find('input,textarea,select,button').each(function (index, element) {
                                $(element).removeAttr('disabled');
                            });
                            $(button).html(prev_button);
                            action(Result, name_form_temp, form);
                        }, $.config.time_form);
                    };
                    if (form_send == true) {
                        if (send == true) {
                            data = $(hasform).getJSON();
                            $.AddData({ Name: name, Exec: exec, Data: data, Type: type, Table: table, Condition: condition });
                            $.SendData({ onSuccess: onSuccess, onBefore: onBefore, onOperacion: onOperacion });
                        } else {
                            data = $(hasform).getJSON(true);
                            action(data, name_form_temp, form);
                        };
                    };
                    return false;
                }
            });

            //Get Information
            var onSuccessQuery = function (Result) {
                //For Add Data Query Controls
                for (var item in ctrl_group) {
                    var inRow = ctrl_group[item];
                    if (inRow.data == true) {
                        var ctrlResult = Result[inRow.encode].Result;
                        if (inRow.type == 'SELECT') {
                            $(inRow.object).html('');
                            if ($(inRow.object).is('[data-set-default]')) {
                                $(inRow.object).append('<option value="">' + $(inRow.object).attr('data-set-default') + '</option>');
                            };
                        };
                        for (var subItem in ctrlResult.Data) {
                            var subRow = ctrlResult.Data[subItem];
                            var arr_field = inRow.field.split(",")
                            var txt_field = '';
                            for (var in_field in arr_field) {
                                var in_field_text = arr_field[in_field];
                                txt_field = txt_field + subRow[in_field_text] + ' - '
                            };
                            if (inRow.type == 'SELECT') {
                                txt_field = txt_field.substring(0, (txt_field.length - 3));
                                $(inRow.object).append('<option value="' + subRow[inRow.value] + '">' + txt_field + '</option>');
                            };
                        };
                        $(inRow.object).val('');
                        if ($(inRow.object).is('[data-first]')) {
                            var val_first = $(inRow.object).find('option').first().attr('value');
                            $(inRow.object).val(val_first);
                        };
                        if (inRow.to != '' && inRow.in != '') {
                            //$(inRow.object).unbind('change');
                            $(inRow.object).bind('change', function () {
                                var value_object = $(this).val();
                                var name_object = $(this).attr('name');
                                var arr_object = ctrl_group[name_object];
                                var data_object = $.local_data[name_object].Result;
                                var to_object = $.GetControl(arr_object.form, arr_object.to);
                                if (to_object.length) {
                                    for (var item in data_object.Data) {
                                        var inRow = data_object.Data[item];
                                        if (inRow[arr_object.value] == value_object) {
                                            $(to_object).val(inRow[arr_object.in]);
                                            $(to_object).trigger('change');
                                            break;
                                        };
                                    };
                                };
                            });
                            $(inRow.object).trigger('change');
                        };

                    };
                };
                //Run Process Callback
                onSuccess(name_form_temp, form);
                //For Query Editable Form
                if (codeQuery !== '') {
                    //alert('hola');
                    var dataOfForm = Result[myToken].Result;
                    if (dataOfForm.Rows == 1) {
                        //console.log(dataOfForm.Data);
                        for (var item in dataOfForm.Data) {
                            var inRow = dataOfForm.Data[item];
                            for (var subItem in inRow) {
                                var control_object = $.GetControl(name_form_temp, subItem);
                                $(control_object).val(inRow[subItem]);
                                condition = condition.replace('{{' + subItem + '}}', inRow[subItem]);
                                $(control_object).trigger('change');
                            };
                        };
                        if (condition != '') {
                            type = 2;
                        };
                    };
                };
            };

            //Runat Success
            if (codeQuery !== '') {
                $.prev_data.TemParams['codeQuery'] = codeQuery;
                $.AddData({ Name: myToken, Exec: 'getQuery', Data: $.prev_data.TemParams, ConvertData: true, noSQL: noSQL });
                total_select++;
            };
            if (total_select != 0) {
                $.SendData({ onSuccess: onSuccessQuery, onOperacion: 'Carga Form.' });
            } else {
                onSuccess(name_form_temp, form);
            };

        });
    },
    DisplayAlert: function (options) {
        return this.each(function () {
            var myPlace = $(this);
            var myPrev = options.Prev || '';
            var myHtml = options.Html || '';
            var myClass = options.Class || 'success';
            var myDismiss = '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>';
            if (myHtml !== '') {
                if (myPrev !== '') {
                    myPrev = '<strong>' + myPrev + '</strong>';
                };
                $(myPlace).html('<div class="alert alert-' + myClass + ' alert-dismissible wow fadeIn" role="alert"><p>' + myDismiss + myPrev + ' ' + myHtml + '</p></div>');
            };
            return $(myPlace);
        });
    },
    LoadTable: function (options) {
        return this.each(function () {

            var myPlace = $(this);
            var codeQuery = options.codeQuery || '';
            var onSuccess = options.onSuccess;
            var myButtons = options.buttons || {};
            var myButtons_HTML = '';
            var myButtons_FRMT = '';
            var myCols_FRMT = '';
            var myFormatters = options.Formatters || {};
            var myCountSelect = 0;
            var myNoSQL = options.noSQL || {};
            var myFormFilter = options.formFilter || '';
            var myHidden = options.hidden || [];
            var myMultiSelect = options.multiSelect || false;
            var myShowFind = options.showFind;
            var myPriotity = options.priority || [];

            if ((typeof options.showFind == "undefined")) {
                myShowFind = true;
            };
            if ((typeof onSuccess == "undefined") || (typeof onSuccess != 'function')) {
                onSuccess = function (Result) { };
            };
            //Message Loading Table
            myPlace.html('<span class="table-temp">' + $.GetMessage('load_table') + '</span>');
            //Process Buttons
            for (var item in myButtons) {
                var inRow = myButtons[item];
                var inClass = inRow.class || 'btn-default';
                var inIcon = inRow.icon || '';
                var inName = $.CreateEncode();
                var inSelect = inRow.select || false;
                inRow.name = inName;
                if (inIcon == '' && inSelect == true) inIcon = "fa fa-star-o";
                if (inIcon != '') inIcon = "<i class='" + inIcon + "'></i>";
                if (inSelect == false) myButtons_HTML += "<button index='" + item + "' name='" + inName + "' class='btn " + inClass + "' disabled>" + inIcon + ' <span class="hidden-xs">' + item + "</span></button>";
                if (inSelect == true) {
                    myButtons_FRMT += "<button index='" + item + "' name='" + inName + "' class='btn btn-xs " + inClass + "' disabled>" + inIcon + "</button>";
                    myCountSelect++;
                }
            };
            //Set Formatters for Column Options
            if (myCountSelect > 0) myCols_FRMT += '<th data-column-id="Opciones" data-formatter="Opciones" data-sortable="false" data-visible-in-selection="false">Opciones</th>';
            if (myButtons_HTML != '') myButtons_HTML = "<div class='btn-group pull-left'>" + myButtons_HTML + "</div>";
            if (myButtons_FRMT != '') {
                myButtons_FRMT = "<div class='btn-group'>" + myButtons_FRMT + "</div>";
                myFormatters['Opciones'] = function (column, row) {
                    return myButtons_FRMT;
                };
            };
            //Run Create Table Bootgrid
            setTimeout(function () {
                var myToken = $.CreateEncode();
                var onSuccessParent = function (Result) {
                    var myTotalLoad = 0;
                    var myCols = Result[myToken].Result.Cols;
                    var myColsVisible = [];
                    var myColsCount = 0;
                    var myColsCountPriority = 0;
                    var myColsGet = function (colName) {
                        var pos_col=-1;
                        for (var item in myColsVisible) {
                            var inRow = myColsVisible[item];
                            if (typeof inRow.name !== 'undefined') {
                                if (inRow.name == colName) {
                                    pos_col = item;
                                    break;
                                };
                            };
                        };
                        return pos_col;
                    };
                    var myColsSet = function (colName, object) {
                        var configCol = {};
                        var colHidden = false;
                        var indexCol=myColsGet(colName);
                        myColsCount++;
                        for (var hidecol in myHidden) {
                            if (myHidden[hidecol] == colName) {
                                $(object).attr('data-visible', 'false');
                                $(object).attr('data-visible-in-selection', 'false');
                                colHidden = true;
                                break;
                            };
                        };
                        if (typeof myFormatters[colName] != 'undefined') $(object).attr('data-formatter', inRow.ColumnName);
                        if (myColsCount == 1) $(object).attr('data-identifier', 'true');
                        if (colHidden == false) {
                            myColsCountPriority++;
                            if (indexCol == -1) {
                                configCol = { name: colName }
                                myColsVisible.push(configCol);
                            } else {
                                configCol = myColsVisible[indexCol];
                            };
                            configCol.visible = true;
                            configCol.position = myColsCountPriority;
                        };
                    };
                    var myColsStart = function (myTableReceive, myPlaceReceive,totalLoad) {
                        //Set Event Resize Cols Priority
                        if (totalLoad == 1) {
                            $(myPlace).resize(function () {
                                var ColsTotal = myColsVisible.length;
                                var ColsAction = function (visible) {
                                    var ColsHidden = function (ColsObject, visible) {
                                        var return_ajust = 0;
                                        if (ColsObject.visible == visible) {
                                            $(myTable).find('tr').each(function () {
                                                $(this).find('th,td').each(function (index) {
                                                    if ((index + 1) == ColsObject.position) {
                                                        if (visible) {
                                                            $(this).hide();
                                                            $(this).addClass('hidden-resize');
                                                        } else {
                                                            $(this).show();
                                                            $(this).removeClass('hidden-resize');
                                                        };
                                                    };
                                                });
                                            });
                                            ColsObject.visible = !visible;
                                            if ($(myTable).width() <= $(myPlace).width()) {
                                                return_ajust = 1;
                                            } else {
                                                return_ajust = -1;
                                            };
                                        };
                                        return return_ajust;
                                    };
                                    if (visible) {
                                        for (i = ColsTotal - 1; i >= 0; i--) {
                                            if (ColsHidden(myColsVisible[i], visible) == 1) break;
                                        };
                                    } else {
                                        for (i = 0; i < ColsTotal; i++) {
                                            if (ColsHidden(myColsVisible[i], visible) == -1) {
                                                ColsHidden(myColsVisible[i], !visible);
                                                break;
                                            };
                                        };
                                    };
                                };
                                if ($(myTable).width() > $(myPlace).width()) {
                                    ColsAction(true);
                                } else {
                                    ColsAction(false);
                                };
                            });
                        } else {
                            //Reinit Config Columns
                            $(myTable).find('th.hidden-resize,td.hidden-resize').show().removeClass('hidden-resize');
                            for (var item in myColsVisible) {
                                var subRow = myColsVisible[item];
                                subRow.visible = true;
                            };
                        };
                        //Run Resize Event
                        $(myPlace).trigger('resize');
                    };
                    var myHead, myTable;
                    var myTempClick = {};
                    var myTempClick_Call = false;
                    var myRowCount = options.rowCount || $.config.table.rowCount || [50, 100, 150, 200, 250, 300, -1];
                    var myButtonRunat = function (myButtonArray) {
                        var thisName = myButtonArray.name;
                        var thisButton = myPlace.find('button[name=' + thisName + ']');
                        var thisFloat = myButtonArray.float || false;
                        var thisAction = myButtonArray.action || '';
                        var thisSuccess = function () {
                            thisButton.removeAttr('disabled');
                        };
                        if ((typeof thisAction == 'function')) {
                            thisAction($.prev_data.TemParams, myButtonArray.table);
                        };
                        if ((typeof thisAction == 'string')) {
                            if (thisFloat == true) {
                                thisButton.attr('disabled', 'disabled');
                                $.GetPage({ onName: thisAction, onFloat: thisFloat, onSuccess: thisSuccess });
                            } else {
                                $.UpdateHash({ page: thisAction });
                            };
                        };
                        myTempClick = {};
                        myTempClick_Call = false;
                    };
                    var template_header = '';

                    myPlace.html('<table id="' + myToken + '" class="table table-responsive table-hover table-striped" data-role="table" data-mode="columntoggle"><thead></thead></table>');
                    myTable = myPlace.find('table');
                    myHead = myTable.find('thead');

                    myHead.append('<tr></tr>');
                    //Process Priority Columns
                    for (var item in myPriotity) {
                        myColsVisible.push({ name: myPriotity[item] });
                    };
                    //Process Columns in Table
                    for (var item in myCols) {
                        var inRow = myCols[item];
                        if (typeof myNoSQL[inRow.ColumnName] == 'undefined') {
                            myHead.find('tr').append('<th data-column-id="' + inRow.ColumnName + '">' + inRow.ColumnName + '</th>');
                            myColsSet(inRow.ColumnName, myHead.find('tr').find('th').last());
                        } else {
                            for (var subitem in myNoSQL[inRow.ColumnName]) {
                                myHead.find('tr').append('<th data-column-id="' + subitem + '">' + subitem + '</th>');
                                myColsSet(subitem, myHead.find('tr').find('th').last());
                            };
                        };
                    };
                    //Add Columns Options if Exist
                    if (myCols_FRMT != '') myHead.find('tr').append(myCols_FRMT);
                    if (typeof $.prev_data.TemParams == 'undefined') $.prev_data.TemParams = {};
                    if (typeof $.prev_data.SaveParams == 'undefined') $.prev_data.SaveParams = {};
                    $.prev_data.TemParams = {};
                    //If Display Forms Search
                    if (myShowFind == true) {
                        template_header = "<div id=\"{{ctx.id}}\" class=\"{{css.header}}\"><div class=\"row\"><div class=\"actionBar\">" + myButtons_HTML + "<p class=\"{{css.search}}\"></p><p class=\"{{css.actions}}\"></p></div></div></div>"
                    } else {
                        template_header = "<div id=\"{{ctx.id}}\" class=\"{{css.header}}\"><div class=\"row\"><div class=\"actionBar\">" + myButtons_HTML + "<p class=\"{{css.actions}}\"></p></div></div></div>"
                    };

                    myTable.bootgrid({
                        codeQuery: codeQuery,
                        url: $.config.service_url,
                        ajax: true,
                        noSQL: myNoSQL,
                        formFilter: myFormFilter,
                        templates: {
                            header: template_header
                        },
                        multiSelect: myMultiSelect,
                        selection: myMultiSelect,
                        rowSelect: myMultiSelect,
                        keepSelection: false,
                        formatters: myFormatters,
                        labels: {
                            all: "Todo",
                            infos: "Mostrando {{ctx.start}} hasta {{ctx.end}}, de un total de {{ctx.total}} regs.",
                            loading: "Cargando...",
                            noResults: "No hay resultados que mostrar en este momento!",
                            refresh: "Actualizar",
                            search: "Buscar"
                        },
                        rowCount: myRowCount
                    }).on("loaded.rs.jquery.bootgrid", function (e) {
                        for (var item in myButtons) {
                            var inRow = myButtons[item];
                            var inAction = inRow.action || '';
                            var inSelect = inRow.select || false;
                            var inTitle = inRow.title || item;
                            var inMultiSelect = inRow.multiSelect || false;
                            var myButton = myPlace.find('button[name=' + inRow.name + ']');

                            inRow.multiSelect = inMultiSelect;
                            inRow.table = myTable;

                            if (inAction != '') {
                                myButton.removeAttr('disabled');
                                myButton.attr('title', inTitle);
                                myButton.unbind('click');
                                myButton.bind('click', function () {
                                    var thisName = $(this).attr('index');
                                    var thisButton = myButtons[thisName];
                                    var thisSelect = thisButton.select || false;
                                    myTempClick_Call = true;
                                    if (thisSelect == false) {
                                        $.prev_data.TemParams = {};
                                        myButtonRunat(thisButton);
                                    } else {
                                        myTempClick = thisButton;
                                        myTempClick_Call = true;
                                    };
                                });
                            };
                            if (inMultiSelect == true) {
                                myButton.attr('disabled', 'disabled');
                            };
                        };
                        //Count Number of Process
                        myTotalLoad++;
                        //Run OnSuccess Client Success By Step Load
                        onSuccess(myTable, myPlace, myTotalLoad);
                        //Run Default Success Config and Resize Cols
                        if (typeof $.config.table.onSuccess != 'undefined') {
                            if (typeof $.config.table.onSuccess == 'function') {
                                $.config.table.onSuccess(myTable, myPlace, myTotalLoad);
                            };
                        };
                        //Run Start Cols Priority
                        myColsStart(myTable, myPlace, myTotalLoad);
                    }).on("click.rs.jquery.bootgrid", function (e, column, row) {
                        if (myTempClick_Call == true) {
                            //Save Params
                            var mySave = myTempClick.save || {};
                            for (var item in mySave) {
                                if (typeof row[item] != 'undefined') {
                                    $.prev_data.SaveParams[mySave[item]] = row[item];
                                };
                            };
                            //Temp Params
                            $.prev_data.TemParams = row;
                            myButtonRunat(myTempClick);
                        };
                    }).on("selected.rs.jquery.bootgrid", function (e, rows) {
                        for (var item in myButtons) {
                            if (myButtons[item].multiSelect == true) {
                                var thisButton = myPlace.find('button[name=' + myButtons[item].name + ']');
                                thisButton.removeAttr('disabled');
                            };
                        };
                    }).on("deselected.rs.jquery.bootgrid", function (e, rows) {
                        var tempRows = $(myTable).bootgrid("getSelectedRows");
                        if (tempRows.length == 0) {
                            for (var item in myButtons) {
                                if (myButtons[item].multiSelect == true) {
                                    var thisButton = myPlace.find('button[name=' + myButtons[item].name + ']');
                                    thisButton.attr('disabled', 'disabled');
                                };
                            };
                        };
                    });
                };
                $.AddData({ Name: myToken, Exec: 'getQuery', Data: [{ name: 'codeQuery', value: codeQuery }] });
                $.SendData({ onSuccess: onSuccessParent, onOperacion: 'Crear Grid' });
            }, $.config.time_form);

        });
    },
    CreateLoadFile: function (options) {
        return this.each(function () {

            var myPlace = $(this);
            var myFileName = $.CreateEncode();
            var onSelected = options.onSelected;
            var onCreated = options.onCreated;
            var onSuccess = options.onSuccess;
            var onNomen = options.onNomen || '';
            var myInput;

            if ((typeof onSuccess == "undefined") || (typeof onSuccess != 'function')) {
                onSuccess = function (Result) { };
            };
            if ((typeof onSelected == "undefined") || (typeof onSelected != 'function')) {
                onSelected = function (Result) { };
            };
            if ((typeof onCreated == "undefined") || (typeof onCreated != 'function')) {
                onCreated = function (Result) { };
            };

            myPlace.append('<input id="' + myFileName + '" name="' + myFileName + '" type="file" multiple=true class="file-loading">');

            myInput = $(myPlace).find("#" + myFileName);

            options.uploadUrl = $.config.service_url;
            options.uploadAsync = true;
            options.language = $.config.user_language;
            options.mainClass = 'input-group-sm';
            options.showAjaxErrorDetails = false;
            options.uploadExtraData = { 'Nomen': onNomen };

            myInput.fileinput(options);

            //After Load File from Explorer
            myInput.on("filebatchselected", function (event, files) {
                onSelected(event, files);
                if (options.showUpload == false) {
                    myInput.fileinput("upload");
                };
            });
            //Before Send File to Server
            myInput.on('filepreupload', function (event, data, previewId, index) {
                //console.log('File pre upload triggered');
            });
            //After Send File to Server
            myInput.on("fileuploaded", function (event, data, previewId, index) {
                $.SaveData(data.response);
                var name_work = data.response.Petition[0].Name;
                var data_work = $.local_data[name_work];
                $('.kv-file-remove').hide();
                onSuccess(data_work, myInput, data_work.Result.Data[0]);
            });
            //Error on Send File to Server
            myInput.on("fileuploaderror", function (event, data, previewId, index) {
                //console.log(data);
            });

            onCreated(myInput);

        });
    },
    ShowCalendar: function (options) {
        return this.each(function () {
            var myPlace = $(this);
            var myToken = $.CreateEncode();
            var myToday = moment();
            var defOptions = {
                format: 'L',
                maxDate: myToday,
                focusOnShow: true
            };
            var myOptions = options || defOptions;

            myOptions.locale = $.config.user_language;

            $(myPlace).wrap('<div class="input-group date" id="' + myToken + '"></div>');
            $(myPlace).attr('maxlength', '10');
            $(myPlace).closest('#' + myToken).append('<span class="input-group-addon"><span class="glyphicon glyphicon-calendar"></span></span>');
            $(myPlace).closest('#' + myToken).datetimepicker(myOptions);

            $(myPlace).mask('00/00/0000', { placeholder: "dd/mm/aaaa" });

            return myPlace;
        });
    },
    ExportExcel: function (options) {
        return this.each(function () {

            var datenum = function (v, date1904) {
                if (date1904) v += 1462;
                var epoch = Date.parse(v);
                return (epoch - new Date(Date.UTC(1899, 11, 30))) / (24 * 60 * 60 * 1000);
            };

            var sheet_from_array_of_arrays = function (data, opts) {
                var ws = {};
                var range = { s: { c: 10000000, r: 10000000 }, e: { c: 0, r: 0 } };
                for (var R = 0; R != data.length; ++R) {
                    for (var C = 0; C != data[R].length; ++C) {
                        if (range.s.r > R) range.s.r = R;
                        if (range.s.c > C) range.s.c = C;
                        if (range.e.r < R) range.e.r = R;
                        if (range.e.c < C) range.e.c = C;
                        var cell = { v: data[R][C] };
                        if (cell.v == null) continue;
                        var cell_ref = XLSX.utils.encode_cell({ c: C, r: R });

                        if (typeof cell.v === 'number') cell.t = 'n';
                        else if (typeof cell.v === 'boolean') cell.t = 'b';
                        else if (cell.v instanceof Date) {
                            cell.t = 'n'; cell.z = XLSX.SSF._table[14];
                            cell.v = datenum(cell.v);
                        }
                        else cell.t = 's';

                        ws[cell_ref] = cell;
                    }
                }
                if (range.s.c < 10000000) ws['!ref'] = XLSX.utils.encode_range(range);
                return ws;
            };

            var s2ab = function (s) {
                var buf = new ArrayBuffer(s.length);
                var view = new Uint8Array(buf);
                for (var i = 0; i != s.length; ++i) view[i] = s.charCodeAt(i) & 0xFF;
                return buf;
            };
            var Workbook = function () {
                if (!(this instanceof Workbook)) return new Workbook();
                this.SheetNames = [];
                this.Sheets = {};
            };
            var name_export = options.name_export || $.CreateEncode();
            var name_sheet = options.name_sheet || $.CreateEncode();

            $(this).TableToArray({
                onSuccess: function (Result) {

                    var data_export = Result;
                    var wb = new Workbook();
                    var ws = sheet_from_array_of_arrays(data_export);

                    wb.SheetNames.push(name_sheet);
                    wb.Sheets[name_sheet] = ws;

                    var wbout = XLSX.write(wb, { bookType: 'xlsx', bookSST: true, type: 'binary' });

                    name_export += ".xlsx";
                    saveAs(new Blob([s2ab(wbout)], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" }), name_export);

                }
            });

        });
    },
    TableToArray: function (options) {
        return this.each(function () {

            var table_object = $(this);
            var table_arr = [];
            var onSuccess = options.onSuccess;

            if ((typeof onSuccess == "undefined") || (typeof onSuccess != 'function')) {
                onSuccess = function (Result) { };
            };

            $(table_object).find('tr').each(function () {
                var table_arr_tr = [];
                $(this).find('th,td').each(function () {
                    table_arr_tr.push($(this).text());
                });
                table_arr.push(table_arr_tr);
            });

            onSuccess(table_arr);

        });
    },
    setLoginForm: function (onSuccess) {
        return this.each(function () {
            var form_control = $(this);
            form_control.ValidForm({
                ButtonText: $.GetMessage('login_button'),
                Send: true,
                Exec: 'getQuery',
                onSuccess: function (NameForm, OBJForm) {
                    $(OBJForm).prepend('<div id="login-alert"></div>');
					if(typeof onSuccess =='function') onSuccess(NameForm,OBJForm);
                },
                Action: function (Result,NameForm) {
                    var MyResult = Result[NameForm];
                    var MyRows = MyResult.Result.Rows;
                    var MyData = MyResult.Result.Data;
                    var MyReady = false;
                    if (MyRows == 0) {
                        $('#login-alert').DisplayAlert({ //Error Access Login
                            Prev: '<i class="fa fa-exclamation-circle"></i> Oops',
                            Html: 'sus datos de acceso no son v&aacute;lidos, intentelo nuevamente.',
                            Class: 'warning'
                        });
                    } else {
                        for (var item in $.config.login) {
                            var inRow = $.config.login[item];
                            if (MyData[0].SESSIONSTATUS == inRow.code) {
                                if (typeof inRow.action === 'function') {
                                    inRow.action(form_control, MyData[0]);
                                    MyReady = true;
                                    break;
                                } else {
                                    //trace log
                                };
                            };
                        };
                        if (MyReady == false) {
                            //trace log
                            $('#login-alert').DisplayAlert({
                                Prev: '<i class="fa fa-exclamation-circle"></i> Oops',
                                Html: 'sus datos de acceso no son v&aacute;lidos, intentelo nuevamente.',
                                Class: 'warning'
                            });
                        };
                    };
                }
            });
        });
    }
});
