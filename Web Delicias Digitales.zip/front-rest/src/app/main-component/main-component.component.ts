import { Component } from '@angular/core';
declare var $: any;

@Component({
  selector: 'app-main-component',
  standalone: true,
  imports: [],
  templateUrl: './main-component.component.html',
  styleUrl: './main-component.component.css'
})
export class MainComponentComponent {

  ngOnInit(): void {
    this.initializeJS();
  }

  initializeJS(): void {

    // Llama a las funciones de tus archivos JavaScript aquí
    console.log('JavaScript inicializado');

    // Ejemplo de uso de jQuery
    $(document).ready(function () {
      console.log('jQuery está listo');
    });
    
  }

}
