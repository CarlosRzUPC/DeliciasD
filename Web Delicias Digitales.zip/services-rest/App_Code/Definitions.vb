﻿Imports Microsoft.VisualBasic
Imports System.Runtime.Serialization
Imports System.Runtime.Serialization.Json

Public Class Definitions

    ''Config Table Json Return
    <DataContract()> Public Class TableJson
        <DataMember()> Public current As Double = 1
        <DataMember()> Public rowCount As Double = 10
        <DataMember()> Public rows As Object = Nothing
        <DataMember()> Public cols As Object = Nothing
        <DataMember()> Public total As Double = 0
        <DataMember()> Public misc As Object = Nothing
    End Class

    ''Config Theme
    <DataContract()> Public Class Theme
        <DataMember()> Public info As New InfoItem
        <DataMember()> Public design As List(Of DesignItem)
        <DataContract()> Public Class InfoItem
            <DataMember()> Public name As String = ""
            <DataMember()> Public version As String = ""
            <DataMember()> Public autor As String = ""
            <DataMember()> Public url As String = ""
            <DataMember()> Public update As String = ""
        End Class
        <DataContract()> Public Class DesignItem
            <DataMember()> Public name As String = ""
            <DataMember()> Public path As String = ""
            <DataMember()> Public title As String = ""
            <DataMember()> Public mode As String = ""
            <DataMember()> Public login As Double = False
        End Class
    End Class

    'Definitions form Client Petition
    <DataContract()> Public Class ClientJson
        <DataMember()> Public Petition As New List(Of Form)
        <DataMember()> Public Session As New List(Of FormItem)
        <DataMember()> Public Browser As New List(Of FormItem)
        <DataMember()> Public Operacion As String = "Transaccion"
        <DataMember()> Public Encoding As String = ""
        <DataMember()> Public InitTime As DateTime = Now
        <DataMember()> Public LastTime As DateTime = Now
        <DataContract()> Public Class Form
            <DataMember()> Public App As Integer = 0
            <DataMember()> Public Exec As String = ""
            <DataMember()> Public Token As String = ""
            <DataMember()> Public Name As String = ""
            <DataMember()> Public Type As Integer = 1
            <DataMember()> Public Table As String = ""
            <DataMember()> Public Condition As String = ""
            <DataMember()> Public TableToken As String = ""
            <DataMember()> Public Query As String = ""
            <DataMember()> Public Data As New List(Of FormItem)
            <DataMember()> Public Result As New FormResult
            <DataMember()> Public noSQL As Object = Nothing
            Public Function IncrementItem(name As String, Optional value As Object = Nothing, Optional encripter As Boolean = False) As FormItem
                Dim TempItem As New FormItem
                TempItem.name = name
                TempItem.value = value
                TempItem.encripter = encripter
                Me.Data.Add(TempItem)
                Return TempItem
            End Function
        End Class
        <DataContract()> Public Class FormItem
            <DataMember()> Public encripter As Boolean = False
            <DataMember()> Public original As String = ""
            <DataMember()> Public name As String = ""
            <DataMember()> Public value As Object = Nothing
            <DataMember()> Public nosend As Double = 0
        End Class
        <DataContract()> Public Class FormResult
            <DataMember()> Public InitTime As String = ""
            <DataMember()> Public LastTime As String = ""
            <DataMember()> Public Log As List(Of FormLog)
            <DataMember()> Public Result As Object = Nothing
        End Class
        <DataContract()> Public Class FormLog
            <DataMember()> Public Time As String = ""
            <DataMember()> Public Type As String = ""
            <DataMember()> Public Message As String = ""
            <DataMember()> Public Query As String = ""
            <DataMember()> Public Index As Double = -1
            <DataMember()> Public Control As Object = Nothing
        End Class
        <DataContract()> Public Class HtmlFile
            <DataMember()> Public Name As String = ""
            <DataMember()> Public Title As String = ""
            <DataMember()> Public HTML As Object
            <DataMember()> Public Descrip As String = ""
            <DataMember()> Public Mode As String = "json"
        End Class
        <DataContract()> Public Class TableJson
            <DataMember()> Public Rows As Double = 0
            <DataMember()> Public Cols As Object = Nothing
            <DataMember()> Public Data As Object = Nothing
        End Class
    End Class

    ''Aplication Configuration
    <DataContract()> Public Class Config
        <DataMember()> Public server As New ServerItem
        <DataMember()> Public local As New LocalItem
        <DataMember()> Public client As New ClientItem
        <DataMember()> Public mail As New MailItem
        <DataMember()> Public app As New AppItem
        <DataContract()> Public Class ServerItem
            <DataMember()> Public host_name As String = ""
            <DataMember()> Public user_name As String = ""
            <DataMember()> Public pwd_name As String = ""
            <DataMember()> Public bd_name As String = ""
            <DataMember()> Public editable As Boolean = False
        End Class
        <DataContract()> Public Class LocalItem
            <DataMember()> Public plugin As String = ""
            <DataMember()> Public media As String = ""
            <DataMember()> Public print As String = ""
            <DataMember()> Public app As String = ""
            <DataMember()> Public theme As String = ""
            <DataMember()> Public upload As String = ""
            <DataMember()> Public editable As Boolean = False
            <DataMember()> Public query As List(Of QueryItem)
            <DataContract()> Public Class QueryItem
                <DataMember()> Public name As String = ""
                <DataMember()> Public transact As String = ""
            End Class
        End Class
        <DataContract()> Public Class ClientItem
            <DataMember()> Public service As String = ""
            <DataMember()> Public theme As String = ""
            <DataMember()> Public editable As Boolean = False
        End Class
        <DataContract()> Public Class MailItem
            <DataMember()> Public domain As String = ""
            <DataMember()> Public smtp As Integer = 25
            <DataMember()> Public pop As Integer = 110
            <DataMember()> Public imap As Integer = 143
            <DataMember()> Public user_name As String = ""
            <DataMember()> Public full_name As String = ""
            <DataMember()> Public pwd_name As String = ""
        End Class
        <DataContract()> Public Class InfoFiles
            <DataMember()> Public Path As String = ""
            <DataMember()> Public File As String = ""
            <DataMember()> Public Name As String = ""
            <DataMember()> Public Url As String = ""
            <DataMember()> Public Type As String = ""
            <DataMember()> Public Active As Boolean = False
        End Class
        <DataContract()> Public Class AppItem
            <DataMember()> Public install As Boolean = False
            <DataMember()> Public theme As String = "install"
            <DataMember()> Public editable As Boolean = False
        End Class
    End Class
End Class
