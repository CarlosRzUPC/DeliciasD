﻿Imports Microsoft.VisualBasic
Imports System.Data
Imports System.Data.Sql
Imports System.Data.SqlTypes
Imports System.Data.SqlClient
Imports System.Web
Imports System.Web.Script
Imports System.Web.Script.Serialization

Public Class Objects

    Public Conexion As SqlConnection
    Private IsConnect As Boolean = False
    Public LogGroup As New List(Of Definitions.ClientJson.FormLog)
    Public MyCommand As New SqlCommand
    Private MyAdapter As New SqlDataAdapter
    Private MyBuilder As New SqlCommandBuilder
    Private MyDataSet As New DataSet
    Public AllowLog As Boolean = True

    Public Sub New(OBJConfig As Definitions.Config.ServerItem)

        System.Threading.Thread.CurrentThread.CurrentCulture = New System.Globalization.CultureInfo("es-PE")
        System.Threading.Thread.CurrentThread.CurrentCulture.DateTimeFormat.ShortDatePattern = "dd/MM/yyyy"
        System.Threading.Thread.CurrentThread.CurrentCulture.DateTimeFormat.LongDatePattern = "dd/MM/yyyy"
        System.Threading.Thread.CurrentThread.CurrentCulture.NumberFormat.CurrencyDecimalSeparator = "."
        System.Threading.Thread.CurrentThread.CurrentCulture.NumberFormat.CurrencyGroupSeparator = ","
        System.Threading.Thread.CurrentThread.CurrentCulture.NumberFormat.NumberDecimalSeparator = "."
        System.Threading.Thread.CurrentThread.CurrentCulture.NumberFormat.NumberGroupSeparator = ","

        With OBJConfig
            Conexion = New SqlConnection
            Conexion.ConnectionString = "Data Source=" & .host_name & ";Initial Catalog=" & .bd_name & ";User ID=" & .user_name & ";Password=" & .pwd_name & ";Connect Timeout=15"
            Try
                Me.Conexion.Open()
                If (AllowLog = True) Then CreateLog("OK", "Coneccion Establecida.", , Conexion.ConnectionString)
                Me.Conexion.Close()
                IsConnect = True
            Catch ex As Exception
                CreateLog("ERROR", "SERVER", , Conexion.ConnectionString)
                CreateLog("ERROR", ex.Message)
            End Try
        End With
    End Sub
    Protected Overrides Sub Finalize()
        MyBase.Finalize()
    End Sub

    Public Function CreateLog(TypeLog As String, MessageLog As String, Optional Index As Double = -1, Optional Query As String = "", Optional Control As Object = Nothing) As String
        Dim LogItem As New Definitions.ClientJson.FormLog
        LogItem.Time = Now
        LogItem.Type = TypeLog
        LogItem.Message = MessageLog
        LogItem.Index = Index
        LogItem.Query = Query
        LogItem.Control = Control
        LogGroup.Add(LogItem)
        Return MessageLog
    End Function

    Public Function SaveData(Data As Definitions.ClientJson.Form) As DataTable
        ''Vars of Function
        Dim MyTabla As DataTable = GetData(Data)
        Dim MyRow As DataRow = Nothing
        Dim MyIsField As Double = False
        Dim MyQueryTMP As String = ""
        Dim MyQueryTBL As New DataTable
        ''Evaluate problems
        Try
            ''Validate to Use Row
            If Data.Type = 1 Then
                MyRow = MyTabla.NewRow
            End If

            ''Update Data on Row
            With Data.Data
                For i As Integer = 0 To .LongCount - 1
                    MyIsField = MyTabla.Columns.Contains(.Item(i).name)
                    If .Item(i).nosend = 0 And MyIsField = True Then
                        Select Case MyTabla.Columns(.Item(i).name).DataType.FullName
                            Case "System.Int32"
                                .Item(i).value = Val(.Item(i).value)
                            Case "System.Decimal"
                                .Item(i).value = Val(.Item(i).value)
                            Case "System.DateTime"
                                If Len(.Item(i).value) = 0 Then
                                    .Item(i).value = MyTabla.Columns(.Item(i).name).DefaultValue
                                End If
                        End Select
                        If Data.Type = 1 Then MyRow.Item(.Item(i).name) = .Item(i).value
                        If Data.Type = 2 Then
                            For Each SubRow As DataRow In MyTabla.Rows
                                SubRow.Item(.Item(i).name) = .Item(i).value
                            Next
                        End If
                    End If
                Next
            End With
            ''Operation Insery or Delete to Table
            If Data.Type = 1 Then
                MyTabla.Rows.Add(MyRow)
            End If
            If Data.Type = 3 Then
                For Each SubRow As DataRow In MyTabla.Rows
                    SubRow.Delete()
                Next
            End If
            ''Update Data
            MyBuilder = New SqlCommandBuilder(MyAdapter)
            MyAdapter.Update(MyTabla)
            ''Log OK
            If (AllowLog = True) Then CreateLog("OK", "Datos registrados con exito.")
            ''LastID Table Save
            If Data.Type = 1 Then
                MyQueryTMP = "SELECT IDENT_CURRENT('" & Data.Table & "') as Token"
                MyQueryTBL = Me.GetData(Data, MyQueryTMP)
                If MyQueryTBL.Rows.Count = 1 Then
                    MyTabla.Columns.Add("Token")
                    MyTabla.Rows(0).Item("Token") = MyQueryTBL.Rows(0).Item("Token")
                    Data.TableToken = MyQueryTBL.Rows(0).Item("Token")
                End If
            End If
        Catch ex As Exception
            CreateLog("ERROR", "SaveData - " + ex.Message)
        End Try
        ''Return Table
        Return MyTabla
    End Function

    Public Function RunQuery(Transact As String) As DataTable

        Dim MyTable As New DataTable

        MyDataSet = New DataSet

        If Len(Transact) > 0 Then
            Try
                MyAdapter = New SqlDataAdapter(Transact, Me.Conexion)
                MyBuilder = New SqlCommandBuilder(MyAdapter)
                MyAdapter.Fill(MyDataSet)
                If (AllowLog = True) Then CreateLog("OK", "Consulta Realizada con Exito.", , Transact)
                MyTable = MyDataSet.Tables(0)
            Catch ex As Exception
                CreateLog("ERROR", "RunQuery - " + ex.Message, , Transact)
            End Try
        Else
            CreateLog("ERROR", "No se ha definido el QUERY para esta operacion.")
        End If

        Return MyTable

    End Function

    Public Function GetData(Data As Definitions.ClientJson.Form, Optional TextQuery As String = "") As DataTable

        Dim MyTable As DataTable

        If (Len(TextQuery) = 0) Then
            TextQuery = Data.Query
        End If

        MyTable = RunQuery(TextQuery)

        Return MyTable
    End Function

    Public Function GetDataJson(Data As Definitions.ClientJson.Form) As Definitions.ClientJson.TableJson
        Dim MyTabla As DataTable = GetData(Data) ''Reading Dataset
        Return ConvertJson(MyTabla) ''Convert and Return to Json
    End Function

    Public Function ConvertJson(ByVal MyTabla As DataTable) As Definitions.ClientJson.TableJson

        Dim serializer As New JavaScriptSerializer()
        Dim rows As New List(Of Dictionary(Of String, Object))()
        Dim row As Dictionary(Of String, Object) = Nothing
        Dim objReturn As New Definitions.ClientJson.TableJson

        Dim cols As New Dictionary(Of String, Object)()
        Dim col As Dictionary(Of String, Object) = Nothing

        For Each dr As DataRow In MyTabla.Rows
            row = New Dictionary(Of String, Object)()
            ''Row Value
            For Each dc As DataColumn In MyTabla.Columns
                row.Add(dc.ColumnName.Trim(), dr.Item(dc.ColumnName).ToString)
            Next
            ''Add Row
            rows.Add(row)
        Next

        For Each dc As DataColumn In MyTabla.Columns
            col = New Dictionary(Of String, Object)()
            ''Properties
            col.Add("ColumnName", dc.ColumnName.ToString)
            col.Add("DataType", dc.DataType.Name.ToString)
            col.Add("DefaultValue", dc.DefaultValue.ToString)
            col.Add("MaxLength", dc.MaxLength.ToString)
            ''Add List Columns
            cols.Add(dc.ColumnName, col)
        Next

        objReturn.Cols = cols
        objReturn.Rows = MyTabla.Rows.Count
        objReturn.Data = rows

        Return objReturn

    End Function

End Class
