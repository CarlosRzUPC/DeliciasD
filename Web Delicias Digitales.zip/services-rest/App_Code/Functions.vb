﻿Imports Microsoft.VisualBasic
Imports System
Imports System.Runtime.Serialization
Imports System.Runtime.Serialization.Json
Imports System.Net
Imports System.Web
Imports System.Web.Script.Serialization
Imports System.IO
Imports System.IO.Compression
Imports System.Collections
Imports System.Text
Imports System.Security
Imports System.Security.Cryptography
Imports System.Data
Imports System.Data.Sql
Imports System.Data.SqlClient
Imports System.NullReferenceException
Imports System.Net.Mail

Public Class Functions

    Private DefaultConfig As String = "~/lib/config/config.json"
    Public MyConfig As Definitions.Config
    Private MySession As List(Of Definitions.ClientJson.FormItem)
    Private MyBrowser As List(Of Definitions.ClientJson.FormItem)
    Public MyRequest As HttpRequest
    Public MyRootObject As New Definitions.ClientJson

    Public Sub New()
        MyConfig = GetConfig()
    End Sub

    Public Function CreateResult() As Definitions.ClientJson.FormResult
        Dim MyResult As New Definitions.ClientJson.FormResult
        MyResult.InitTime = Now
        MyResult.Log = New List(Of Definitions.ClientJson.FormLog)
        Return MyResult
    End Function

    Public Function WorkJson(RootObject As Definitions.ClientJson) As Definitions.ClientJson
        ''Vars For Working
        Dim MyData As New Definitions.ClientJson.Form
        Dim MyRows As Double = 0
        Dim MyConfigUse As Definitions.Config = MyConfig
        ''Setting GLobak Root Object
        MyRootObject = RootObject
        ''Session
        MySession = RootObject.Session
        MyBrowser = RootObject.Browser
        RootObject.InitTime = Now
        ''By Each Petition
        For Each MyData In RootObject.Petition
            MyRows += 1
            ''Add Token to Petition
            MyData.Token = EncodeText(MyRows)
            If Len(MyData.Name) = 0 Then
                MyData.Name = MyData.Token
            End If
            ''Run Method
            MyData.Result = CallByName(Me, MyData.Exec, CallType.Method, MyConfigUse, MyData)
            ''Evaluating Sending Email after Process
            If Len(Me.GetValueOfData(MyData.Data, "TemplateEmail")) > 0 Then
                Me.SendEmail(MyConfigUse, MyData)
            End If
            ''End time process
            MyData.Result.LastTime = Now
        Next
        RootObject.LastTime = Now
        ''Return object
        Return MyRootObject
    End Function

    Public Function SetData(Config As Definitions.Config, Data As Definitions.ClientJson.Form) As Definitions.ClientJson.FormResult
        ''Vars Functions
        Dim MyObject As New Objects(Config.server)
        Dim MyResult As Definitions.ClientJson.FormResult = CreateResult()
        ''Finding Type Of Query
        Data.Query = CreateTransact(Data, MyObject)
        ''Run Save Data Now
        MyResult.Result = MyObject.ConvertJson(MyObject.SaveData(Data))
        MyResult.Log = MyObject.LogGroup
        ''Return Json
        Return MyResult
    End Function

    Public Function SavePrintFile(Config As Definitions.Config, Data As Definitions.ClientJson.Form) As Definitions.ClientJson.FormResult

        Dim MyResult As Definitions.ClientJson.FormResult = CreateResult()
        Dim MyFile_Content As String = GetValueOfData(Data.Data, "HtmlText")
        Dim MyFile_TypePath As String = GetValueOfData(Data.Data, "TypePath", Config.local.print)
        Dim MyFile_Path As String = HttpContext.Current.Server.MapPath(MyFile_TypePath & "\print.html")
        Dim MyFile As FileStream
        Dim MyFile_Stream As StreamWriter

        Try

            MyFile = New FileStream(MyFile_Path, FileMode.Create, FileAccess.Write)
            MyFile_Stream = New StreamWriter(MyFile)
            MyFile_Stream.WriteLine(MyFile_Content)
            MyFile_Stream.Close()
            MyFile.Close()

			''File.Copy(MyFile_Path, "\\\\192.168.0.18\\PrintNona", True)
			
            MyResult.Result = MyFile_Path

        Catch ex As Exception

            MyResult.Result = ex.Message

        End Try

        Return MyResult

    End Function

    Public Function GetFileToDonwload(Config As Definitions.Config, Data As Definitions.ClientJson.Form) As Definitions.ClientJson.FormResult
        ''Vars Functions
        Dim MyObject As New Objects(Config.server)
        Dim MyResult As Definitions.ClientJson.FormResult = CreateResult()
        Dim MyFile_Query As String = GetTransact("T_GetArchivo", Data.Data, Config)
        Dim MyTabla As DataTable = MyObject.GetData(Data, MyFile_Query)
        Dim MiFileToDonwload As String = ""

        ''Finding File
        If (MyTabla.Rows.Count > 0) Then
            MiFileToDonwload = GetUrlPath(MyTabla.Rows(0).Item("RutaGuardado"))
        End If

        ''Allocate Result
        MyResult.Result = MiFileToDonwload
        MyResult.Log = MyObject.LogGroup
        ''Return Data JSON
        Return MyResult
    End Function

    Public Function GetQuery(Config As Definitions.Config, Data As Definitions.ClientJson.Form) As Definitions.ClientJson.FormResult
        ''Vars Functions
        Dim MyObject As New Objects(Config.server)
        Dim MyResult As Definitions.ClientJson.FormResult = CreateResult()
        Dim NameOfQuery As String = GetValueOfData(Data.Data, "codeQuery")
        Dim filterForm As Object = GetValueOfData(Data.Data, "Filter-Form")
        ''Finding Type Of Query
        Data.Query = GetTransact(NameOfQuery, Data.Data, Config, filterForm)
        ''Allocate Result
        MyResult.Result = MyObject.GetDataJson(Data)
        MyResult.Log = MyObject.LogGroup
        ''Return Data JSON
        Return MyResult
    End Function

    Public Function GetTransact(CodeTransact As String, Data As IList(Of Definitions.ClientJson.FormItem), Config As Definitions.Config, Optional RulesTransact As String = "") As String
        ''Var to Return
        Dim MyQueryTransact As String = ""
        Dim MyTypeValue As String = ""
        Dim MyFound As Boolean = False
        Dim MyObject As New Objects(Config.server)
        Dim MyTable As New DataTable

        ''Finding Transact SQL in Local Save
        With MyConfig.local.query
            For i As Integer = 0 To .LongCount - 1
                If UCase(.Item(i).name) = UCase(CodeTransact) Then
                    MyQueryTransact = .Item(i).transact
                    MyFound = True
                    Exit For
                End If
            Next
            If MyFound = False Then
                ''Set Default Code Transact
                CodeTransact = GetValueOfData(Data, "codeQueryInner", CodeTransact, True)
                ''Getting Server
                MyQueryTransact = GetTransact("T_GetTransact", Data, Config)
                MyTable = MyObject.RunQuery(MyQueryTransact)
                If MyTable.Rows.Count = 1 Then
                    MyQueryTransact = MyTable.Rows(0).Item("ScriptSQL").ToString
                    MyFound = True
                End If
            End If
        End With
        If MyFound = True Then
            ''Aply Rules Transact
            If Len(RulesTransact) > 0 Then
                MyQueryTransact = Replace(RulesTransact, "{{Query}}", MyQueryTransact)
            End If
            ''Analice Conditional
            With Data ''Data Receive
                For i As Integer = 0 To .LongCount - 1
                    MyTypeValue = .Item(i).value.GetType.Name
                    If MyTypeValue <> "Object[]" Then
                        .Item(i).original = .Item(i).value
                        If .Item(i).encripter = True Then
                            .Item(i).value = EncodeText(.Item(i).value)
                            .Item(i).encripter = False
                        End If
                        MyQueryTransact = Replace(MyQueryTransact, "{{" & .Item(i).name & "}}", .Item(i).value, CompareMethod.Text)
                    End If
                Next
            End With
            With MySession ''Session
                For i As Integer = 0 To .LongCount - 1
                    MyTypeValue = .Item(i).value.GetType.Name
                    If MyTypeValue <> "Object[]" Then
                        .Item(i).original = .Item(i).value
                        If .Item(i).encripter = True Then
                            .Item(i).value = EncodeText(.Item(i).value)
                            .Item(i).encripter = False
                        End If
                        MyQueryTransact = Replace(MyQueryTransact, "{{" & .Item(i).name & "}}", .Item(i).value, CompareMethod.Text)
                    End If
                Next
            End With
        End If
        ''Return Transact SQL
        Return MyQueryTransact
    End Function

    Public Function CreateTransact(Data As Definitions.ClientJson.Form, MyObject As Objects) As String
        ''Vars Functions
        Dim NameOfTable As String = Data.Table
        Dim TypeOfTransac As Double = Data.Type
        Dim WhereOfTable As String = Data.Condition
        Dim QueryTransact As String = ""
        Dim Continuar As Boolean = True
        ''Evaluat Default Vars
        If Len(NameOfTable) = 0 Then
            MyObject.CreateLog("ERROR", "Nombre de tabla vacia, sin esta dato no hay operacion.")
            Continuar = False
        End If
        ''Is Ok Vars Continue Now
        If Continuar = True Then
            QueryTransact = "SELECT"
            If TypeOfTransac = 1 Then
                QueryTransact = QueryTransact & " TOP 0"
            End If
            QueryTransact = QueryTransact & " * "
            With Data.Data
                For i As Integer = 0 To .LongCount - 1
                    .Item(i).original = .Item(i).value
                    If .Item(i).encripter = True Then
                        .Item(i).value = EncodeText(.Item(i).value)
                        .Item(i).encripter = False
                    End If
                Next
            End With
            If Right(QueryTransact, 1) = "," Then
                QueryTransact = Left(QueryTransact, Len(QueryTransact) - 1)
            End If
            QueryTransact = QueryTransact & " FROM " & NameOfTable
            If TypeOfTransac = 2 Or TypeOfTransac = 3 Then
                QueryTransact = QueryTransact & " WHERE " & WhereOfTable
            End If
        End If
        ''return Result Query
        Return QueryTransact
    End Function

    Public Function GetTable(Config As Definitions.Config, Data As Definitions.ClientJson.Form) As Definitions.ClientJson.FormResult

        Dim MyObject As New Objects(Config.server)
        Dim MyResult As Definitions.ClientJson.FormResult = CreateResult()
        Dim MyTableReturn As New Definitions.TableJson
        Dim MyTableRead As New Definitions.ClientJson.TableJson
        Dim NameOfQuery As String = GetValueOfData(Data.Data, "codeQuery")
        Dim Current As Double = GetValueOfData(Data.Data, "current")
        Dim rowCount As Double = GetValueOfData(Data.Data, "rowCount")
        Dim searchPhrase As String = GetValueOfData(Data.Data, "searchPhrase")
        Dim sort As Object = GetValueOfData(Data.Data, "sort")
        Dim filterForm As Object = GetValueOfData(Data.Data, "Filter-Form")
        Dim MyQueryCount As String = "select count(0) as Total from ({{Query}}) as TempQuery"
        Dim MyQueryData As String = "select*from ({{Query}}) as TempQuery ORDER BY 1 DESC"
        Dim MyQueryDataTemp As String = "select top 0 * from ({{Query}}) as TempQuery"
        Dim MyQueryDataTempTable As DataTable
        Dim TotalReturn As Double = 0
        Dim ColOrderTable As String = ""
        Dim ColOrderTableMethod As String = "ASC"

        Data.Query = GetTransact(NameOfQuery, Data.Data, Config, filterForm)

        MyQueryDataTemp = Replace(MyQueryDataTemp, "{{Query}}", Data.Query)
        MyQueryDataTempTable = MyObject.RunQuery(MyQueryDataTemp)
        ColOrderTable = MyQueryDataTempTable.Columns(0).ColumnName

        MyQueryData = "SELECT ROW_NUMBER() OVER (ORDER BY " & ColOrderTable & " " & ColOrderTableMethod & ") AS RowNumToken,* from ({{Query}}) as A"
        If (rowCount > 0) Then
            MyQueryData = "SELECT * FROM (" & MyQueryData & ") as TempQuery WHERE RowNumToken BETWEEN " & ((Current - 1) * rowCount + 1) & " AND " & (Current * rowCount)
        End If

        MyQueryCount = Replace(MyQueryCount, "{{Query}}", Data.Query)
        MyQueryData = Replace(MyQueryData, "{{Query}}", Data.Query)

        Data.Query = MyQueryData
        If (MyObject.GetData(Nothing, MyQueryCount).Rows.Count > 0) Then
            TotalReturn = MyObject.GetData(Nothing, MyQueryCount).Rows(0).Item("Total")
        End If

        MyTableRead = MyObject.GetDataJson(Data)
        MyTableReturn.rows = MyTableRead.Data
        MyTableReturn.total = TotalReturn
        MyTableReturn.cols = MyTableRead.Cols
        MyTableReturn.current = Current
        MyTableReturn.rowCount = rowCount

        MyResult.Log = MyObject.LogGroup
        MyResult.Result = MyTableReturn

        Return MyResult

    End Function

    Public Function GetTheme(Config As Definitions.Config, Data As Definitions.ClientJson.Form) As Definitions.ClientJson.FormResult

        Dim MyObject As New Objects(Config.server)
        Dim MyResult As Definitions.ClientJson.FormResult = CreateResult()
        Dim MyModelSelect As String = GetValueOfData(Data.Data, "design", "")
        Dim MyThemPathDef As String = GetValueOfData(Data.Data, "path", Config.client.theme)
        Dim MyThemeConfig As New Definitions.Theme
        Dim Serializer As New JavaScriptSerializer
        Dim MyTheme As String = ""
        Dim MyHtml As New Definitions.ClientJson.HtmlFile
        Dim MyDesignUse As New Definitions.Theme.DesignItem
        Dim MyDegignCount As Double = 0
        Dim MyDegignLoad As Boolean = False
        ''Is Install Application
        If Config.app.install = False Then
            MyThemPathDef = Config.app.theme
        End If
        ''Selecction Desing Path Theme
        MyThemeConfig = GetThemeConfig(Config.local.theme & "/" & MyThemPathDef & "/design.json")
        For Each MyDesign As Definitions.Theme.DesignItem In MyThemeConfig.design
            MyDegignCount += 1
            If Len(MyModelSelect) > 0 Then
                If UCase(MyDesign.name) = UCase(MyModelSelect) Then
                    If MyDesign.login = True Then
                        If MySession.Count > 0 Then
                            MyDegignLoad = True
                        End If
                    Else
                        MyDegignLoad = True
                    End If
                    If MyDegignLoad = True Then
                        MyDesignUse = MyDesign
                        Exit For
                    End If
                End If
            Else
                If MyDegignCount = 1 And MySession.Count = 0 Then
                    MyDesignUse = MyDesign
                    MyDegignLoad = True
                    Exit For
                End If
                If MyDegignCount = 2 And MySession.Count > 0 Then
                    MyDesignUse = MyDesign
                    MyDegignLoad = True
                    Exit For
                End If
                If (MyThemeConfig.design.Count = 1 And MySession.Count > 0) Then
                    MyDesignUse = MyDesign
                    MyDegignLoad = True
                    Exit For
                End If
            End If
        Next

        ''Loading Theme Found
        If MyDegignLoad = True Then
            MyTheme = GetFileContent(Config.local.theme & "/" & MyThemPathDef & "/" & MyDesignUse.path)
            MyHtml.Name = MyDesignUse.name
            MyHtml.Title = MyDesignUse.title
            MyHtml.Mode = LCase(Replace(IO.Path.GetExtension(MyDesignUse.path), ".", ""))
            If MyHtml.Mode = "json" Then MyHtml.HTML = Serializer.Deserialize(Of Object)(MyTheme)
            If MyHtml.Mode = "html" Then MyHtml.HTML = MyTheme
        End If
        ''Set Result Values of Theme
        MyResult.Log = MyObject.LogGroup
        MyResult.Result = MyHtml

        Return MyResult

    End Function

    Public Function GetPage(Config As Definitions.Config, Data As Definitions.ClientJson.Form) As Definitions.ClientJson.FormResult
        ''Vars Functions
        Dim MyObject As New Objects(Config.server)
        Dim MyResult As Definitions.ClientJson.FormResult = CreateResult()
        Dim MyHtml As New Definitions.ClientJson.HtmlFile
        Dim MyTable As DataTable
        ''Finding Type Of Query
        Data.Query = GetTransact("T_GetWebPage", Data.Data, Config)
        MyTable = MyObject.GetData(Data)
        ''Process HTML
        If MyTable.Rows.Count > 0 Then
            MyHtml.Name = Me.EncodeText(MyTable.Rows(0).Item("IdWebPage"))
            MyHtml.Title = MyTable.Rows(0).Item("Titulo")
            MyHtml.HTML = GetFileContent(MyTable.Rows(0).Item("Archivo"))
            MyHtml.Mode = "html"
            MyHtml.Descrip = MyTable.Rows(0).Item("Descripcion")
        End If
        ''Allocate Result
        MyResult.Result = MyHtml
        MyResult.Log = MyObject.LogGroup
        ''Return Data JSON
        Return MyResult
    End Function

    ''Sending Email
    Public Function SendEmail(Config As Definitions.Config, Data As Definitions.ClientJson.Form) As Definitions.ClientJson.FormResult

        ''Vars Functions
        Dim MyObject As New Objects(Config.server)
        Dim MyResult As Definitions.ClientJson.FormResult = CreateResult()
        Dim MyTemplQuery As String = Me.GetTransact("T_GetTemplate", Data.Data, Config)
        Dim MyTemplTable As DataTable = MyObject.GetData(Data, MyTemplQuery)
        Dim MyBodyHTML As String = ""
        Dim MySubject As String = ""
        Dim MyMail As MailMessage
        Dim MyFieldNameToSend As String = Me.GetValueOfData(Data.Data, "TemplateEmailTo", "Email")
        Dim MyEmailTo As String = Me.GetValueOfData(Data.Data, MyFieldNameToSend)
        Dim NetworkCred As NetworkCredential
        Dim Smtp As SmtpClient

        ''Evaluate and Processing Mensagge Compose
        If MyTemplTable.Rows.Count = 1 Then
            MyBodyHTML = MyTemplTable.Rows(0).Item("Mensaje")
            MySubject = MyTemplTable.Rows(0).Item("Asunto")
            For Each FieldData As Definitions.ClientJson.FormItem In Data.Data
                MyBodyHTML = Replace(MyBodyHTML, "{{" & FieldData.name & "}}", FieldData.original)
            Next
            Try
                MyMail = New MailMessage
                With MyMail
                    .From = New MailAddress(MyConfig.mail.user_name, MyConfig.mail.full_name)
                    .Subject = MySubject
                    .IsBodyHtml = True
                    .Body = MyBodyHTML
                    .To.Add(MyEmailTo)
                End With
                NetworkCred = New NetworkCredential(MyConfig.mail.user_name, MyConfig.mail.pwd_name)
                Smtp = New SmtpClient
                With Smtp
                    .Host = MyConfig.mail.domain
                    .EnableSsl = False
                    .UseDefaultCredentials = True
                    .Credentials = NetworkCred
                    .Port = MyConfig.mail.smtp
                    .Send(MyMail)
                End With
            Catch ex As Exception
                MyObject.CreateLog("Error.Mail", ex.ToString)
            End Try
        End If

        ''Allocate Result
        MyResult.Result = MyBodyHTML
        MyResult.Log = MyObject.LogGroup
        ''Return Data JSON
        Return MyResult

    End Function

    Public Function GetValueOfData(Data As IList(Of Definitions.ClientJson.FormItem), NameItem As String, Optional DefaultValue As Object = "", Optional ForceValue As Boolean = False) As Object
        Dim ValueFind As Object = ""
        Dim ValueForm As New Definitions.ClientJson.FormItem
        ''Analice Conditional
        With Data
            For i As Integer = 0 To .LongCount - 1
                If .Item(i).name.ToUpper = NameItem.ToUpper Then
                    If ForceValue = True Then
                        .Item(i).value = DefaultValue
                    End If
                    ValueFind = .Item(i).value
                    Exit For
                End If
            Next
        End With
        ''Evaluate Default to Return
        If Len(ValueFind.ToString) = 0 Then

            If ForceValue = True Then
                ValueForm.name = NameItem
                ValueForm.value = DefaultValue
                Data.Add(ValueForm)
            End If

            Return DefaultValue
        Else
            Return ValueFind
        End If

    End Function

    Private Function GetThemeConfig(DesignFile As String) As Definitions.Theme
        Dim BodyJsonEnd As String = GetFileContent(DesignFile)
        Dim Serializer As New DataContractJsonSerializer(GetType(Definitions.Theme))
        Dim StreamJson As New MemoryStream(Encoding.UTF8.GetBytes(BodyJsonEnd))
        Dim SrvObject As Definitions.Theme = DirectCast(Serializer.ReadObject(StreamJson), Definitions.Theme)
        Return SrvObject
    End Function

    Private Function GetConfig() As Definitions.Config
        Dim BodyJsonEnd As String = GetFileContent(DefaultConfig)
        Dim Serializer As New DataContractJsonSerializer(GetType(Definitions.Config))
        Dim StreamJson As New MemoryStream(Encoding.UTF8.GetBytes(BodyJsonEnd))
        Dim SrvObject As Definitions.Config = DirectCast(Serializer.ReadObject(StreamJson), Definitions.Config)
        Return SrvObject
    End Function

    Public Function GetUrlPath(LocalPath As String) As String
        Return LocalPath.Replace(HttpRuntime.AppDomainAppPath, "").Replace(Path.DirectorySeparatorChar, "/")
    End Function
    Public Function GetRelativePath(LocalPath As String) As String
        Dim request As HttpRequest = HttpContext.Current.Request
        Dim applicationPath As String = request.PhysicalApplicationPath
        Dim virtualPath As String = request.ApplicationPath
        virtualPath = "~" & virtualPath
        Return LocalPath.Replace(applicationPath, virtualPath).Replace("\", "/")
    End Function

    Private Function GetFileFromPath(PathWork As String, ParamArray FilterDirectory() As String) As List(Of Definitions.Config.InfoFiles)

        Dim MyDirectories() As String
        Dim MyDirectorie As String = ""
        Dim MyFiles() As String
        Dim MyFile As String
        Dim MyFileInfo As FileInfo
        Dim MyFileReturn As New List(Of Definitions.Config.InfoFiles)
        Dim MyFileItem As New Definitions.Config.InfoFiles
        Dim Enc As Boolean = True

        PathWork = HttpContext.Current.Server.MapPath(PathWork)

        If Directory.Exists(PathWork) = True Then
            MyDirectories = Directory.GetDirectories(PathWork)
            For Each MyDirectorie In MyDirectories
                If FilterDirectory.Length > 0 Then
                    Enc = False
                    For x As Integer = LBound(FilterDirectory) To UBound(FilterDirectory)
                        If UCase(FilterDirectory(x)) = UCase(Right(MyDirectorie, Len(FilterDirectory(x)))) Then
                            Enc = True
                            Exit For
                        End If
                    Next
                End If
                If Enc = True Then
                    MyFiles = Directory.GetFiles(MyDirectorie)
                    For Each MyFile In MyFiles
                        MyFileInfo = New FileInfo(MyFile)
                        MyFileItem = New Definitions.Config.InfoFiles
                        MyFileItem.File = MyFile
                        MyFileItem.Name = Replace(MyFileInfo.Name, MyFileInfo.Extension, "")
                        MyFileItem.Path = MyFileInfo.Directory.Name
                        MyFileItem.Type = MyFileInfo.Extension
                        MyFileItem.Url = GetUrlPath(MyFile)
                        MyFileItem.Active = True
                        MyFileReturn.Add(MyFileItem)
                    Next
                End If
            Next
            MyFiles = Directory.GetFiles(PathWork)
            For Each MyFile In MyFiles
                MyFileInfo = New FileInfo(MyFile)
                MyFileItem = New Definitions.Config.InfoFiles
                MyFileItem.File = MyFile
                MyFileItem.Name = Replace(MyFileInfo.Name, MyFileInfo.Extension, "")
                MyFileItem.Path = MyFileInfo.Directory.Name
                MyFileItem.Type = MyFileInfo.Extension
                MyFileItem.Url = GetUrlPath(MyFile)
                MyFileItem.Active = True
                MyFileReturn.Add(MyFileItem)
            Next
        End If
        Return MyFileReturn
    End Function

    Public Function GetFileContent(FileName As String) As String
        Dim ObjReader As IO.StreamReader
        Dim ObjContent As String = ""
        Dim ObjFileName As String = HttpContext.Current.Server.MapPath(FileName)
        If IO.File.Exists(ObjFileName) = True Then
            ObjReader = New IO.StreamReader(ObjFileName)
            ObjContent = ObjReader.ReadToEnd
            ObjReader.Dispose()
        End If
        Return ObjContent
    End Function

    Public Function PagerLoader(ByRef PageToLoad As System.Web.UI.Page, Optional Ref As String = "Plugin") As Object

        Dim MyCssLnk As New HtmlLink
        Dim ObjectLoad As New List(Of Definitions.Config.InfoFiles)

        Select Case Ref
            Case "Plugin"
                ObjectLoad = GetFileFromPath(MyConfig.local.plugin)
            Case "Theme"
                ObjectLoad = GetFileFromPath(MyConfig.local.theme, MyConfig.client.theme)
        End Select
        With ObjectLoad
            For i As Integer = 0 To .LongCount - 1

                Select Case .Item(i).Type
                    Case ".js"
                        PageToLoad.ClientScript.RegisterClientScriptInclude("Script" & Ref & "_" & i + 1, .Item(i).Url)
                    Case ".css"
                        MyCssLnk = New HtmlLink
                        MyCssLnk.Attributes.Add("Id", "prueba")
                        MyCssLnk.Attributes.Add("rel", "Stylesheet")
                        MyCssLnk.Attributes.Add("type", "text/css")
                        MyCssLnk.Href = .Item(i).Url
                        PageToLoad.Header.Controls.Add(MyCssLnk)
                    Case Else
                        .Item(i).Active = False
                End Select

            Next
        End With
        MyCssLnk.Dispose()

        Return ObjectLoad

    End Function

    Public Function EncodeText(Value As String, Optional Salt As String = "", Optional HashName As String = "SHA1") As String
        'Encoding Value
        Dim Bytes As Byte() = Encoding.Unicode.GetBytes(Value)
        Dim Src As Byte() = Convert.FromBase64String(Salt)
        Dim Dst(Src.Length + Bytes.Length) As Byte
        'Convert Buffer Bytes
        System.Buffer.BlockCopy(Src, 0, Dst, 0, Src.Length)
        System.Buffer.BlockCopy(Bytes, 0, Dst, Src.Length, Bytes.Length)
        ''Indicates SHA1
        Dim HashAlg As Cryptography.HashAlgorithm = Cryptography.HashAlgorithm.Create(HashName)
        Dim inArray = HashAlg.ComputeHash(Dst)
        ''Return Encript Value
        Return Convert.ToBase64String(inArray)
    End Function

    Shared Function GetMd5Hash(ByVal md5Hash As MD5, ByVal input As String) As String

        Dim data As Byte() = md5Hash.ComputeHash(Encoding.UTF8.GetBytes(input))
        Dim sBuilder As New StringBuilder()
        Dim i As Integer

        For i = 0 To data.Length - 1
            sBuilder.Append(data(i).ToString("x2"))
        Next i

        Return sBuilder.ToString()

    End Function

    Public Function UploadFileServer(FileReceive As HttpFileCollection, CookieReceive As HttpCookieCollection) As Definitions.ClientJson

        Dim Petition As New Definitions.ClientJson
        Dim Petition_Form As New Definitions.ClientJson.Form

        Dim NameOfFile As String = ""
        Dim NameOfFile_Encode As String = ""
        Dim PathSave As String = MyConfig.local.upload
        Dim PathSave_Child As String = Format(Now, "ddMMyyyy")
        Dim PathSave_File As String = HttpContext.Current.Server.MapPath(PathSave & "/" & PathSave_Child)
        Dim TotalFiles As Double = 0
        Dim NameOfile_Ext As String = ""

        Dim MDHash As MD5 = MD5.Create
        Dim Nomenclatura As String = MyRequest.Form("Nomen")

        If Directory.Exists(PathSave_File) = False Then
            Directory.CreateDirectory(PathSave_File)
        End If

        For i = 0 To FileReceive.Count - 1

            TotalFiles = Directory.GetFiles(PathSave_File).Length + 1
            NameOfFile_Encode = GetMd5Hash(MDHash, PathSave_Child & "-" & TotalFiles)
            NameOfFile = FileReceive.Item(i).FileName
            NameOfile_Ext = IO.Path.GetExtension(NameOfFile)

            If Len(Nomenclatura) > 0 Then
                Nomenclatura = Replace(Nomenclatura, "{año}", Year(Now))
                Nomenclatura = Replace(Nomenclatura, "{mes}", Right("00" & Month(Now), 2))
                Nomenclatura = Replace(Nomenclatura, "{dia}", Right("00" & Day(Now), 2))
                Nomenclatura = Replace(Nomenclatura, "{id}", Right("0000000" & TotalFiles, 7))
                Nomenclatura = Replace(Nomenclatura, "{usuario}", MyRequest.Cookies("SESSIONID").Value)
                NameOfFile_Encode = Nomenclatura
            End If

            FileReceive.Item(i).SaveAs(PathSave_File & "\" & NameOfFile_Encode & NameOfile_Ext)

            Petition_Form = New Definitions.ClientJson.Form
            Petition_Form.Exec = "SetData"
            Petition_Form.Table = "Archivo"
            Petition_Form.Type = 1

            Petition_Form.IncrementItem("FechaRegistro", Now)
            Petition_Form.IncrementItem("NombreOriginal", NameOfFile)
            Petition_Form.IncrementItem("NombreGuardado", NameOfFile_Encode & NameOfile_Ext)
            Petition_Form.IncrementItem("RutaWeb", GetUrlPath(PathSave_File & "\" & NameOfFile_Encode & NameOfile_Ext))
            Petition_Form.IncrementItem("RutaGuardado", GetRelativePath(PathSave_File & "\" & NameOfFile_Encode & NameOfile_Ext))
            Petition_Form.IncrementItem("Tipo", FileReceive.Item(i).ContentType.ToString)
            Petition_Form.IncrementItem("Tamanio", Math.Round(FileReceive.Item(i).ContentLength / 1024, 0))
            Petition_Form.IncrementItem("IdUsuario", 2) ''Valor temporal debe enviar los cookies
            Petition_Form.IncrementItem("IdEstado", 7)

            Petition.Petition.Add(Petition_Form)

        Next

        Return Petition

    End Function

    Public Function ReadFileData(FileRead As String, MyObject As Objects) As DataTable

        Dim MyTableReturn As New DataTable
        Dim MyConnectStr As String = "Driver={Microsoft Excel Driver (*.xls, *.xlsx, *.xlsm, *.xlsb)};DBQ=" & FileRead & ";readonly=0;usercommitsync=Yes"
        Dim MyConnect As New Data.Odbc.OdbcConnection(MyConnectStr)
        Dim MyAdapter As New Data.Odbc.OdbcDataAdapter
        Dim MyDs As New DataSet
        Dim MyTableSchema As New DataTable
        Dim MyNameSheetQuery As String = ""

        Try
            MyConnect.Open()
            MyTableSchema = MyConnect.GetSchema("Tables")
            For Each MyRow As DataRow In MyTableSchema.Rows
                MyNameSheetQuery = MyRow.Item("TABLE_NAME").ToString()
                If InStr(UCase(MyNameSheetQuery), "DATA$", CompareMethod.Text) > 0 Then
                    Exit For
                End If
            Next
            MyAdapter = New Odbc.OdbcDataAdapter("select*from [" & MyNameSheetQuery & "]", MyConnect)
            MyAdapter.Fill(MyDs)
            MyTableReturn = MyDs.Tables(0)
            MyConnect.Close()
        Catch ex As Exception
            MyObject.CreateLog("ERROR", ex.Message)
            MyObject.CreateLog("ERROR.MASIVO", "El archivo que ha utilizado no tiene datos validos que procesar, revise las instrucciones de carga detenidamente para evitar estos errores.")
        End Try

        Return MyTableReturn

    End Function




End Class
