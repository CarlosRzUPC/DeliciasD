﻿
Partial Class _Default
    Inherits System.Web.UI.Page
    Private MyFunction As New Functions
    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        'MyFunction.PagerLoader(Page, "Plugin")
        'MyFunction.PagerLoader(Page, "Theme")
    End Sub
End Class
